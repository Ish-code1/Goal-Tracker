package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.ui.components.CustomDatePickerModal
import com.example.ui.components.CustomTimePickerModal
import com.example.ui.components.RingProgress
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.GoalTrackerViewModel
import com.example.util.DateUtils
import com.example.util.GoalCalculations
import java.util.Calendar

@Composable
fun TodayScreen(
    viewModel: GoalTrackerViewModel,
    goals: List<Goal>,
    logs: List<LogEntry>,
    selectedDate: String,
    modifier: Modifier = Modifier
) {
    val todayStr = remember { DateUtils.todayDs() }
    val isToday = selectedDate == todayStr
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Date picker state
    var showDatePicker by remember { mutableStateOf(false) }

    val effectiveGoals = remember(goals, logs) { GoalCalculations.adjustGoals(goals, logs) }

    // Session log inputs
    val activeGoals = remember(effectiveGoals) { effectiveGoals.filter { it.dn == null } }
    var selectedGoalId by remember {
        mutableStateOf(activeGoals.firstOrNull()?.id ?: "")
    }
    if (selectedGoalId.isEmpty() && activeGoals.isNotEmpty()) {
        selectedGoalId = activeGoals.first().id
    }

    val currentGoal = remember(effectiveGoals, selectedGoalId) {
        effectiveGoals.find { it.id == selectedGoalId } ?: effectiveGoals.firstOrNull()
    }
    val currentGoalColor = remember(currentGoal) {
        currentGoal?.let { GoalCalculations.parseHexColor(it.col) } ?: DefaultAccent
    }

    var timeSpentInput by remember { mutableStateOf("") }
    var countInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var startTimeInput by remember { mutableStateOf("") }
    var endTimeInput by remember { mutableStateOf("") }
    var timeUnit by remember { mutableStateOf("m") } // "m" or "h"

    var showStartTimePicker by remember { mutableStateOf(false) }
    var showEndTimePicker by remember { mutableStateOf(false) }

    var isLogCardExpanded by remember { mutableStateOf(true) }
    var isGoalProgressExpanded by remember { mutableStateOf(true) }

    // Daily entries for selected date
    val dayEntries = remember(logs, selectedDate) {
        logs.filter { it.d == selectedDate }.sortedBy { it.t }
    }

    val agg = remember(logs) { GoalCalculations.aggregate(logs) }
    val dayProgress = remember(effectiveGoals, selectedDate, agg) {
        GoalCalculations.completionForDay(effectiveGoals, selectedDate, agg) ?: 0.0
    }

    val xp = remember(logs) { GoalCalculations.xpOf(logs) }
    val level = remember(xp) { GoalCalculations.levelOf(xp) }
    val currentStreak = remember(logs, todayStr) { GoalCalculations.streak(logs, todayStr) }
    val longestStreak = remember(logs) { GoalCalculations.longestStreak(logs) }
    val dayTotalMinutes = remember(dayEntries) { dayEntries.sumOf { it.m } }

    // Greeting & dynamic subtitle message
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = if (isToday) {
        when {
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
    } else {
        "Viewing ${DateUtils.formatDM(selectedDate)}"
    }

    val dynamicMessage = remember(goals, dayEntries, dayProgress, selectedDate, agg) {
        when {
            goals.isEmpty() -> "Add your first goal to begin."
            dayEntries.isEmpty() && !goals.any { GoalCalculations.isGoalActiveOnDay(it, selectedDate, agg) } ->
                "No active goals on this day."
            dayProgress >= 0.999 -> "All targets done today. Well played."
            dayEntries.isEmpty() -> "Fresh day. Log your first session, even 10 minutes counts."
            else -> {
                var worstGoal: Goal? = null
                var worstComp = 2.0
                goals.forEach { g ->
                    if (GoalCalculations.isGoalActiveOnDay(g, selectedDate, agg)) {
                        val stats = agg[g.id]?.get(selectedDate)
                        val c = GoalCalculations.comp(g, stats)
                        if (c < worstComp) {
                            worstComp = c
                            worstGoal = g
                        }
                    }
                }
                if (worstGoal != null) {
                    val g = worstGoal!!
                    val stats = agg[g.id]?.get(selectedDate) ?: com.example.util.DayStats()
                    val leftH = GoalCalculations.dh(g) - (stats.m / 60.0)
                    val leftU = GoalCalculations.du(g) - stats.u
                    val amountStr = if (GoalCalculations.dh(g) > 0 && leftH > 0) {
                        "${DateUtils.round1(leftH)} h"
                    } else if (leftU > 0) {
                        "${DateUtils.round1(leftU)} ${g.un}"
                    } else {
                        "almost there"
                    }
                    "Next up: ${g.name}, $amountStr to go."
                } else {
                    "Keep going."
                }
            }
        }
    }

    // Badges logic
    val totalHoursLogged = logs.sumOf { it.m } / 60.0
    val totalCountLogged = logs.sumOf { it.u }
    val hasTargetDay = remember(logs, goals, agg) {
        val uniqueDays = logs.map { it.d }.distinct()
        uniqueDays.any { d ->
            val c = GoalCalculations.completionForDay(goals, d, agg)
            c != null && c >= 0.999
        }
    }

    val badges = listOf(
        Triple("1st", "First log", logs.isNotEmpty()),
        Triple("3d", "3-day streak", longestStreak >= 3),
        Triple("7d", "7-day streak", longestStreak >= 7),
        Triple("30d", "30-day streak", longestStreak >= 30),
        Triple("10h", "10 hours", totalHoursLogged >= 10.0),
        Triple("50h", "50 hours", totalHoursLogged >= 50.0),
        Triple("100", "100 count", totalCountLogged >= 100.0),
        Triple("T", "Target day", hasTargetDay)
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Hero Section Card with subtle radial glow
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            currentGoalColor.copy(alpha = 0.18f),
                            DarkCard,
                            DarkCard
                        ),
                        radius = 650f
                    )
                )
                .padding(22.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = greeting, color = TextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = dynamicMessage,
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        lineHeight = 26.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text(
                            text = "$currentStreak day streak",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (isToday) "${DateUtils.formatHoursMinutes(dayTotalMinutes)} today" else "${DateUtils.formatHoursMinutes(dayTotalMinutes)} on ${DateUtils.formatShort(selectedDate)}",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                RingProgress(
                    progress = dayProgress.toFloat(),
                    accentColor = currentGoalColor,
                    sizeDp = 100
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Date Picker Trigger Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Date", color = TextMuted, fontSize = 13.sp)

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurface2)
                    .clickable { showDatePicker = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "${DateUtils.formatDM(selectedDate)} ▾",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Log a session card
        if (activeGoals.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkCard)
                    .border(
                        width = 1.dp,
                        color = currentGoalColor.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isLogCardExpanded = !isLogCardExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Log a session",
                            color = currentGoalColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isLogCardExpanded) "−" else "+",
                            color = TextMuted,
                            fontSize = 20.sp
                        )
                    }

                    AnimatedVisibility(visible = isLogCardExpanded) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            // Goal selector dropdown
                            var goalDropdownExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurface2)
                                        .clickable { goalDropdownExpanded = true }
                                        .padding(12.dp)
                                ) {
                                    Text(
                                        text = "${currentGoal?.name ?: ""} · ${currentGoal?.un ?: ""}",
                                        color = TextPrimary,
                                        fontSize = 14.sp
                                    )
                                }
                                DropdownMenu(
                                    expanded = goalDropdownExpanded,
                                    onDismissRequest = { goalDropdownExpanded = false },
                                    modifier = Modifier.background(DarkCard)
                                ) {
                                    activeGoals.forEach { g ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = "${g.name} · ${g.un}",
                                                    color = GoalCalculations.parseHexColor(g.col)
                                                )
                                            },
                                            onClick = {
                                                selectedGoalId = g.id
                                                goalDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Daily slot indicator
                            if (currentGoal != null && currentGoal.ws.isNotEmpty() && currentGoal.we.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Daily slot ${currentGoal.ws}–${currentGoal.we}",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Time spent + Unit + Count inputs
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = timeSpentInput,
                                    onValueChange = { timeSpentInput = it },
                                    placeholder = { Text("Time spent", color = TextMuted, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = DarkSurface2,
                                        unfocusedContainerColor = DarkSurface2,
                                        focusedBorderColor = currentGoalColor,
                                        unfocusedBorderColor = Color.Transparent,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )

                                // Unit toggle button (minutes / hours)
                                Box(
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .height(56.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurface2)
                                        .clickable {
                                            timeUnit = if (timeUnit == "m") "h" else "m"
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (timeUnit == "h") "hours" else "minutes",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }

                                OutlinedTextField(
                                    value = countInput,
                                    onValueChange = { countInput = it },
                                    placeholder = { Text("Count", color = TextMuted, fontSize = 12.sp) },
                                    modifier = Modifier.weight(1.1f),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = DarkSurface2,
                                        unfocusedContainerColor = DarkSurface2,
                                        focusedBorderColor = currentGoalColor,
                                        unfocusedBorderColor = Color.Transparent,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Time range: Done from ... until ...
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurface2)
                                        .clickable { showStartTimePicker = true }
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Text("Done from", color = TextMuted, fontSize = 11.sp)
                                        Text(
                                            text = startTimeInput.ifEmpty { "--:--" },
                                            color = TextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurface2)
                                        .clickable { showEndTimePicker = true }
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Text("until", color = TextMuted, fontSize = 11.sp)
                                        Text(
                                            text = endTimeInput.ifEmpty { "--:--" },
                                            color = TextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Note input
                            OutlinedTextField(
                                value = noteInput,
                                onValueChange = { noteInput = it },
                                placeholder = { Text("Note (optional)", color = TextMuted, fontSize = 13.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface2,
                                    unfocusedContainerColor = DarkSurface2,
                                    focusedBorderColor = currentGoalColor,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Log It Button
                            Button(
                                onClick = {
                                    var minutes = 0
                                    val timeVal = timeSpentInput.toDoubleOrNull() ?: 0.0
                                    if (timeVal > 0) {
                                        minutes = if (timeUnit == "h") (timeVal * 60).toInt() else timeVal.toInt()
                                    } else if (startTimeInput.isNotEmpty() && endTimeInput.isNotEmpty()) {
                                        // Calculate duration from time range
                                        val f = { s: String ->
                                            val p = s.split(":")
                                            p[0].toInt() * 60 + p[1].toInt()
                                        }
                                        try {
                                            val d = f(endTimeInput) - f(startTimeInput)
                                            minutes = if (d > 0) d else d + 1440
                                        } catch (_: Exception) {}
                                    }
                                    val countVal = countInput.toDoubleOrNull() ?: 0.0

                                    viewModel.logSession(
                                        goalId = selectedGoalId,
                                        minutes = minutes,
                                        count = countVal,
                                        note = noteInput,
                                        startTime = startTimeInput,
                                        endTime = endTimeInput
                                    )
                                    viewModel.fireConfetti()

                                    // Clear input fields
                                    timeSpentInput = ""
                                    countInput = ""
                                    noteInput = ""
                                    startTimeInput = ""
                                    endTimeInput = ""
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = currentGoalColor,
                                    contentColor = GoalCalculations.onColor(currentGoal?.col ?: "#60a5fa")
                                )
                            ) {
                                Text("Log it", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }
                }
            }
        } else if (goals.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkCard)
                    .padding(18.dp)
            ) {
                Text(
                    text = "All your goals are marked completed. Reopen one in the Goals tab to log more.",
                    color = TextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            Text(
                text = "Add goals first in the Goals tab.",
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // This day's log Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .padding(18.dp)
        ) {
            Column {
                Text(
                    text = "This day's log",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (dayEntries.isEmpty()) {
                    Text(
                        text = "Nothing logged for this day.",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                } else {
                    dayEntries.forEachIndexed { idx, entry ->
                        if (idx > 0) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(DarkBorder)
                            )
                        }

                        val goal = goals.find { it.id == entry.g }
                        val goalCol = goal?.let { GoalCalculations.parseHexColor(it.col) } ?: TextMuted
                        val goalName = goal?.name ?: "Deleted goal"
                        val goalUnits = goal?.un ?: "units"

                        // Slot tag logic
                        val slotTag = if (goal != null && goal.ws.isNotEmpty() && goal.we.isNotEmpty() && goal.ws < goal.we && entry.t.isNotEmpty()) {
                            val inSlot = entry.t >= goal.ws && (entry.t2.ifEmpty { entry.t }) <= goal.we
                            if (inSlot) " · in slot" else " · outside slot"
                        } else ""

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = goalName,
                                    color = goalCol,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                val timeWindow = if (entry.t.isNotEmpty()) {
                                    val t2Str = if (entry.t2.isNotEmpty()) "–${entry.t2}" else ""
                                    "${entry.t}$t2Str$slotTag · "
                                } else ""

                                val noteStr = if (entry.n.isNotEmpty()) " · ${entry.n}" else ""
                                Text(
                                    text = "$timeWindow${DateUtils.formatHoursMinutes(entry.m)} · ${DateUtils.formatNumber(entry.u)} $goalUnits$noteStr",
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            }

                            IconButton(
                                onClick = { viewModel.deleteLog(entry.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Text("×", color = TextMuted, fontSize = 20.sp)
                            }
                        }
                    }
                }

                // Collapsible: Goal progress for this day
                if (goals.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(DarkBorder)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isGoalProgressExpanded = !isGoalProgressExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Goal progress for this day",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isGoalProgressExpanded) "−" else "+",
                            color = TextMuted,
                            fontSize = 18.sp
                        )
                    }

                    AnimatedVisibility(visible = isGoalProgressExpanded) {
                        Column(modifier = Modifier.padding(top = 10.dp)) {
                            goals.forEach { g ->
                                val gLogs = dayEntries.filter { it.g == g.id }
                                val gMinutes = gLogs.sumOf { it.m }
                                val gUnits = gLogs.sumOf { it.u }
                                val gCol = GoalCalculations.parseHexColor(g.col)
                                val isActive = GoalCalculations.isGoalActiveOnDay(g, selectedDate, agg)

                                Column(modifier = Modifier.padding(top = 12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "${g.name}${if (g.dn != null) " ✓" else ""}",
                                            color = gCol,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${DateUtils.formatHoursMinutes(gMinutes)} · ${DateUtils.formatNumber(gUnits)} ${g.un}",
                                            color = TextMuted,
                                            fontSize = 12.sp
                                        )
                                    }

                                    // Progress bars for Hours and Units
                                    val targetH = GoalCalculations.dh(g)
                                    val doneH = DateUtils.hoursFromMinutes(gMinutes)
                                    if (targetH > 0) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        ProgressBarRow("Hours", doneH, targetH, gCol)
                                    }

                                    val targetU = GoalCalculations.du(g)
                                    if (targetU > 0) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        ProgressBarRow(g.un, DateUtils.round1(gUnits), targetU, gCol)
                                    }

                                    // Status / slot details
                                    val statusText = if (!isActive) {
                                        "Not active on this day"
                                    } else {
                                        val slotStr = if (g.ws.isNotEmpty() && g.we.isNotEmpty()) "Daily slot ${g.ws}–${g.we}" else ""
                                        slotStr
                                    }
                                    if (statusText.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(statusText, color = TextMuted, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Badges Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Badges",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${badges.count { it.third }} of ${badges.size}",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    badges.forEach { (code, title, unlocked) ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(66.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .border(
                                        width = 1.5.dp,
                                        color = if (unlocked) DefaultAccent else DarkBorder,
                                        shape = CircleShape
                                    )
                                    .background(if (unlocked) DarkSurface2 else DarkCard),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = code,
                                    color = if (unlocked) DefaultAccent else TextMuted.copy(alpha = 0.4f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = title,
                                color = if (unlocked) TextMuted else TextMuted.copy(alpha = 0.4f),
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        CustomDatePickerModal(
            initialDate = selectedDate,
            onDismissRequest = { showDatePicker = false },
            onDateSelected = { viewModel.setTodayDate(it) }
        )
    }

    if (showStartTimePicker) {
        CustomTimePickerModal(
            initialTime = startTimeInput,
            onDismissRequest = { showStartTimePicker = false },
            onTimeSelected = { startTimeInput = it }
        )
    }

    if (showEndTimePicker) {
        CustomTimePickerModal(
            initialTime = endTimeInput,
            onDismissRequest = { showEndTimePicker = false },
            onTimeSelected = { endTimeInput = it }
        )
    }
}

@Composable
fun ProgressBarRow(
    label: String,
    done: Double,
    total: Double,
    color: Color
) {
    val pct = if (total > 0) ((done / total) * 100).toInt() else 0
    val doneStr = DateUtils.formatNumber(done)
    val totalStr = DateUtils.formatNumber(total)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextMuted, fontSize = 11.sp)
            Text(
                text = if (total > 0) "$doneStr / $totalStr · $pct%${if (pct >= 100) " · done" else ""}" else doneStr,
                color = TextMuted,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(DarkSurface2)
        ) {
            val fillRatio = if (total > 0) (done / total).toFloat().coerceIn(0f, 1f) else 0f
            Box(
                modifier = Modifier
                    .fillMaxWidth(fillRatio)
                    .height(6.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(color)
            )
        }
    }
}
