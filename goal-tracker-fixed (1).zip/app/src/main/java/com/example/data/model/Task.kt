package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "tasks")
@JsonClass(generateAdapter = true)
data class Task(
    @PrimaryKey
    val id: String,
    val name: String,
    val d: String = "", // Deadline date (YYYY-MM-DD), or "" for long-term
    val col: String = "#60a5fa", // Hex color
    val done: Boolean = false
)
