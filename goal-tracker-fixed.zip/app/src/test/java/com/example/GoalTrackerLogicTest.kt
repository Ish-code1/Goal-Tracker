package com.example

import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.util.DateUtils
import com.example.util.GoalCalculations
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GoalTrackerLogicTest {

    @Test
    fun testDateUtils() {
        val d1 = "2026-10-01"
        val d2 = "2026-10-10"
        assertEquals(9, DateUtils.daysDiff(d1, d2))

        val added = DateUtils.addDays(d1, 5)
        assertEquals("2026-10-06", added)

        val formattedDM = DateUtils.formatDM("2026-10-08")
        assertEquals("08/10/2026", formattedDM)

        assertEquals("1h 30m", DateUtils.formatHoursMinutes(90))
        assertEquals("45m", DateUtils.formatHoursMinutes(45))
        assertEquals("2h", DateUtils.formatHoursMinutes(120))
    }

    @Test
    fun testGoalCalculationsBasic() {
        val goal = Goal(
            id = "g1",
            name = "DSA",
            s = "2026-10-01",
            e = "2026-10-10", // 10 days span
            th = 2.0,
            tu = 5.0,
            totalHours = 0.0,
            totalCount = 0.0,
            un = "questions"
        )

        assertEquals(10, GoalCalculations.dys(goal))
        assertEquals(2.0, GoalCalculations.dh(goal), 0.001)
        assertEquals(5.0, GoalCalculations.du(goal), 0.001)
        assertEquals(20.0, GoalCalculations.totH(goal), 0.001)
        assertEquals(50.0, GoalCalculations.totU(goal), 0.001)
    }

    @Test
    fun testTotalTargetMentionedVsFallback() {
        // Case 1: Total mentioned -> uses total target directly, not units*days
        val goalWithTotal = Goal(
            id = "g_total",
            name = "Reading",
            s = "2026-10-01",
            e = "2026-10-10", // 10 days
            th = 1.0, // 1h/day
            tu = 20.0, // 20 pages/day
            totalHours = 35.0, // Explicit total target
            totalCount = 300.0 // Explicit total target
        )
        assertEquals(35.0, GoalCalculations.totH(goalWithTotal), 0.001)
        assertEquals(300.0, GoalCalculations.totU(goalWithTotal), 0.001)

        // Case 2: Total NOT mentioned (0.0) -> fallbacks to daily * days
        val goalWithoutTotal = Goal(
            id = "g_daily_only",
            name = "Workout",
            s = "2026-10-01",
            e = "2026-10-10", // 10 days
            th = 1.5,
            tu = 50.0,
            totalHours = 0.0,
            totalCount = 0.0
        )
        assertEquals(15.0, GoalCalculations.totH(goalWithoutTotal), 0.001) // 1.5 * 10
        assertEquals(500.0, GoalCalculations.totU(goalWithoutTotal), 0.001) // 50 * 10
    }

    @Test
    fun testXpAndLevel() {
        val entries = listOf(
            LogEntry(id = "1", d = "2026-10-01", g = "g1", m = 60, u = 10.0),
            LogEntry(id = "2", d = "2026-10-02", g = "g1", m = 120, u = 5.0)
        )
        // Entry 1: 60 / 6 = 10, 10 * 5 = 50 -> 60 XP
        // Entry 2: 120 / 6 = 20, 5 * 5 = 25 -> 45 XP
        // Total XP = 105
        val xp = GoalCalculations.xpOf(entries)
        assertEquals(105, xp)

        // Level = floor(sqrt(105 / 50)) + 1 = floor(sqrt(2.1)) + 1 = 1 + 1 = 2
        val level = GoalCalculations.levelOf(xp)
        assertEquals(2, level)
    }

    @Test
    fun testStreakCalculation() {
        val entries = listOf(
            LogEntry(id = "1", d = "2026-10-06", g = "g1"),
            LogEntry(id = "2", d = "2026-10-07", g = "g1"),
            LogEntry(id = "3", d = "2026-10-08", g = "g1")
        )
        val streak = GoalCalculations.streak(entries, "2026-10-08")
        assertEquals(3, streak)

        val longest = GoalCalculations.longestStreak(entries)
        assertEquals(3, longest)
    }

    @Test
    fun testPeriodTargetAndOverlap() {
        val goal = Goal(
            id = "g_ov",
            name = "Project",
            s = "2026-10-01",
            e = "2026-10-10", // 10 days
            th = 2.0,
            tu = 10.0,
            totalHours = 40.0,
            totalCount = 200.0
        )

        // Period fully inside: 2026-10-03 to 2026-10-06 (4 days)
        assertEquals(4, GoalCalculations.overlap(goal, "2026-10-03", "2026-10-06"))
        // 40 total * 4 / 10 = 16.0 hours target
        assertEquals(16.0, GoalCalculations.periodTarget(goal, "m", "2026-10-03", "2026-10-06"), 0.001)
        // 200 total * 4 / 10 = 80.0 count target
        assertEquals(80.0, GoalCalculations.periodTarget(goal, "u", "2026-10-03", "2026-10-06"), 0.001)

        // Period completely before: 2026-09-01 to 2026-09-10 (0 days)
        assertEquals(0, GoalCalculations.overlap(goal, "2026-09-01", "2026-09-10"))
        assertEquals(0.0, GoalCalculations.periodTarget(goal, "m", "2026-09-01", "2026-09-10"), 0.001)

        // Period completely after: 2026-10-15 to 2026-10-20 (0 days)
        assertEquals(0, GoalCalculations.overlap(goal, "2026-10-15", "2026-10-20"))
        assertEquals(0.0, GoalCalculations.periodTarget(goal, "m", "2026-10-15", "2026-10-20"), 0.001)
    }

    @Test
    fun testErfAndPhi() {
        // erf(0) should be 0.0
        assertEquals(0.0, GoalCalculations.erf(0.0), 0.0001)
        // phi(0) = 0.5
        assertEquals(0.5, GoalCalculations.phi(0.0), 0.0001)
        // phi(large) -> 1.0
        assertTrue(GoalCalculations.phi(4.0) > 0.999)
        // phi(small) -> 0.0
        assertTrue(GoalCalculations.phi(-4.0) < 0.001)
    }
}
