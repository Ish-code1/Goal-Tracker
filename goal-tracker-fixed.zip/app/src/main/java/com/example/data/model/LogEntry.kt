package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "log_entries")
@JsonClass(generateAdapter = true)
data class LogEntry(
    @PrimaryKey
    val id: String,
    val d: String, // Date (YYYY-MM-DD)
    val g: String, // Goal id
    val m: Int = 0, // Minutes spent
    val u: Double = 0.0, // Count / units done
    val n: String = "", // Note
    val t: String = "", // Start time (HH:mm)
    val t2: String = "" // End time (HH:mm)
)
