package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.BackupData
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.data.model.Task
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow

class GoalTrackerRepository(private val db: AppDatabase) {
    private val goalDao = db.goalDao()
    private val logEntryDao = db.logEntryDao()
    private val taskDao = db.taskDao()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
    private val backupAdapter = moshi.adapter(BackupData::class.java).indent("  ")

    val goalsFlow: Flow<List<Goal>> = goalDao.getAllGoalsFlow()
    val logsFlow: Flow<List<LogEntry>> = logEntryDao.getAllLogsFlow()
    val tasksFlow: Flow<List<Task>> = taskDao.getAllTasksFlow()

    suspend fun insertGoal(goal: Goal) = goalDao.insertGoal(goal)
    suspend fun updateGoal(goal: Goal) = goalDao.updateGoal(goal)
    suspend fun deleteGoal(goalId: String) {
        logEntryDao.deleteLogsForGoal(goalId)
        goalDao.deleteGoalById(goalId)
    }
    suspend fun clearGoalLogs(goalId: String): Int {
        return logEntryDao.deleteLogsForGoal(goalId)
    }

    suspend fun insertLog(entry: LogEntry) = logEntryDao.insertLog(entry)
    suspend fun deleteLog(id: String) = logEntryDao.deleteLogById(id)

    suspend fun insertTask(task: Task) = taskDao.insertTask(task)
    suspend fun updateTask(task: Task) = taskDao.updateTask(task)
    suspend fun deleteTask(id: String) = taskDao.deleteTaskById(id)

    suspend fun seedInitialDataIfEmpty() {
        val today = com.example.util.DateUtils.todayDs()
        var currentGoals = goalDao.getAllGoals()
        if (currentGoals.isEmpty()) {
            val defaultGoals = listOf(
                Goal(
                    id = "g_dsa",
                    name = "DSA Sheet",
                    s = com.example.util.DateUtils.addDays(today, -14),
                    e = com.example.util.DateUtils.addDays(today, 180),
                    ws = "09:00",
                    we = "11:00",
                    th = 2.0,
                    tu = 5.0,
                    totalHours = 200.0,
                    totalCount = 500.0,
                    un = "questions",
                    col = "#60a5fa"
                ),
                Goal(
                    id = "g_sys",
                    name = "System Design",
                    s = com.example.util.DateUtils.addDays(today, -14),
                    e = com.example.util.DateUtils.addDays(today, 120),
                    ws = "14:00",
                    we = "16:00",
                    th = 1.5,
                    tu = 1.0,
                    totalHours = 100.0,
                    totalCount = 60.0,
                    un = "chapters",
                    col = "#34d399"
                ),
                Goal(
                    id = "g_fit",
                    name = "Workout & Gym",
                    s = com.example.util.DateUtils.addDays(today, -14),
                    e = com.example.util.DateUtils.addDays(today, 180),
                    ws = "18:00",
                    we = "19:00",
                    th = 1.0,
                    tu = 10.0,
                    totalHours = 80.0,
                    totalCount = 600.0,
                    un = "sets",
                    col = "#fb923c"
                )
            )
            goalDao.insertGoals(defaultGoals)
            currentGoals = defaultGoals
        }

        if (logEntryDao.getAllLogs().isEmpty()) {
            val g1 = currentGoals.getOrNull(0)?.id ?: "g_dsa"
            val g2 = currentGoals.getOrNull(1)?.id ?: "g_sys"
            val g3 = currentGoals.getOrNull(2)?.id ?: "g_fit"
            val defaultLogs = listOf(
                LogEntry(id = "l_0_1", d = today, g = g1, m = 120, u = 5.0, n = "Graphs & BFS traversal", t = "09:00", t2 = "11:00"),
                LogEntry(id = "l_0_2", d = today, g = g3, m = 60, u = 10.0, n = "Chest & Triceps", t = "18:00", t2 = "19:00"),
                LogEntry(id = "l_1_1", d = com.example.util.DateUtils.addDays(today, -1), g = g1, m = 120, u = 5.0, n = "DP on Trees", t = "09:15", t2 = "11:15"),
                LogEntry(id = "l_1_2", d = com.example.util.DateUtils.addDays(today, -1), g = g2, m = 90, u = 1.0, n = "Rate Limiter design", t = "14:30", t2 = "16:00"),
                LogEntry(id = "l_2_1", d = com.example.util.DateUtils.addDays(today, -2), g = g1, m = 90, u = 4.0, n = "Binary Search practice", t = "09:00", t2 = "10:30"),
                LogEntry(id = "l_2_2", d = com.example.util.DateUtils.addDays(today, -2), g = g3, m = 60, u = 12.0, n = "Back & Biceps", t = "18:00", t2 = "19:00"),
                LogEntry(id = "l_3_1", d = com.example.util.DateUtils.addDays(today, -3), g = g1, m = 120, u = 6.0, n = "Sliding Window problems", t = "09:00", t2 = "11:00"),
                LogEntry(id = "l_3_2", d = com.example.util.DateUtils.addDays(today, -3), g = g2, m = 90, u = 1.0, n = "Consistent Hashing", t = "14:00", t2 = "15:30"),
                LogEntry(id = "l_4_1", d = com.example.util.DateUtils.addDays(today, -4), g = g3, m = 60, u = 10.0, n = "Legs day", t = "18:00", t2 = "19:00"),
                LogEntry(id = "l_5_1", d = com.example.util.DateUtils.addDays(today, -5), g = g1, m = 120, u = 5.0, n = "Two Pointers review", t = "09:00", t2 = "11:00"),
                LogEntry(id = "l_5_2", d = com.example.util.DateUtils.addDays(today, -5), g = g2, m = 90, u = 1.0, n = "Distributed Cache", t = "14:00", t2 = "15:30"),
                LogEntry(id = "l_6_1", d = com.example.util.DateUtils.addDays(today, -6), g = g1, m = 150, u = 7.0, n = "Contest problems", t = "09:00", t2 = "11:30"),
                LogEntry(id = "l_7_1", d = com.example.util.DateUtils.addDays(today, -7), g = g3, m = 60, u = 10.0, n = "Cardio & Core", t = "18:00", t2 = "19:00"),
                LogEntry(id = "l_8_1", d = com.example.util.DateUtils.addDays(today, -8), g = g1, m = 120, u = 5.0, n = "Recursion & Backtracking", t = "09:00", t2 = "11:00")
            )
            logEntryDao.insertLogs(defaultLogs)
        }

        if (taskDao.getAllTasks().isEmpty()) {
            val defaultTasks = listOf(
                Task(id = "t_1", name = "Revise Graph Algorithms", d = today, col = "#60a5fa", done = false),
                Task(id = "t_2", name = "Read Kafka Architecture paper", d = com.example.util.DateUtils.addDays(today, 2), col = "#34d399", done = false),
                Task(id = "t_3", name = "Solve 50 hard LeetCode problems", d = "", col = "#fb923c", done = false)
            )
            taskDao.insertTasks(defaultTasks)
        }
    }

    suspend fun exportBackupJson(): String {
        val goals = goalDao.getAllGoals()
        val tasks = taskDao.getAllTasks()
        val logs = logEntryDao.getAllLogs()
        val groupedLogs = logs.groupBy { entry ->
            if (entry.d.length >= 7) entry.d.substring(0, 7) else "general"
        }
        val backup = BackupData(
            v = 1,
            goals = goals,
            tasks = tasks,
            logs = groupedLogs
        )
        return backupAdapter.toJson(backup)
    }

    suspend fun importBackupJson(jsonString: String): Result<Int> {
        return try {
            val backup = backupAdapter.fromJson(jsonString)
                ?: return Result.failure(IllegalArgumentException("Invalid JSON backup"))
            if (backup.goals.isNotEmpty()) {
                goalDao.insertGoals(backup.goals)
            }
            if (backup.tasks.isNotEmpty()) {
                taskDao.insertTasks(backup.tasks)
            }
            val allEntries = backup.logs.values.flatten()
            if (allEntries.isNotEmpty()) {
                logEntryDao.insertLogs(allEntries)
            }
            Result.success(backup.goals.size + backup.tasks.size + allEntries.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
