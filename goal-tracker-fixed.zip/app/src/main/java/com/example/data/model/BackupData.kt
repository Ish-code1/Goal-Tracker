package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class BackupData(
    val v: Int = 1,
    val goals: List<Goal> = emptyList(),
    val tasks: List<Task> = emptyList(),
    val logs: Map<String, List<LogEntry>> = emptyMap()
)
