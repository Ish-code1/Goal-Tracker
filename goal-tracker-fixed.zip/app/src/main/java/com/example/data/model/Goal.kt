package com.example.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@Entity(tableName = "goals")
@JsonClass(generateAdapter = true)
data class Goal(
    @PrimaryKey
    val id: String,
    val name: String,
    val s: String, // Start date (YYYY-MM-DD)
    val e: String, // Deadline date (YYYY-MM-DD)
    val ws: String = "", // Daily slot start time (HH:mm)
    val we: String = "", // Daily slot end time (HH:mm)
    @ColumnInfo(name = "th")
    val th: Double = 0.0, // Hours per day target
    @ColumnInfo(name = "tu")
    val tu: Double = 0.0, // Count per day target
    @Json(name = "Th")
    @ColumnInfo(name = "total_hours")
    val totalHours: Double = 0.0, // Total hours target
    @Json(name = "Tu")
    @ColumnInfo(name = "total_count")
    val totalCount: Double = 0.0, // Total count target
    val un: String = "units", // What you count
    val col: String = "#60a5fa", // Hex color
    val dn: String? = null, // Completed date (YYYY-MM-DD)
    val dt: String? = null // Completed time (HH:mm)
)
