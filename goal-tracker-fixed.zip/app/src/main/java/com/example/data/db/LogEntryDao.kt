package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.LogEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface LogEntryDao {
    @Query("SELECT * FROM log_entries ORDER BY d DESC, t ASC")
    fun getAllLogsFlow(): Flow<List<LogEntry>>

    @Query("SELECT * FROM log_entries ORDER BY d DESC, t ASC")
    suspend fun getAllLogs(): List<LogEntry>

    @Query("SELECT * FROM log_entries WHERE d = :date ORDER BY t ASC")
    fun getLogsForDateFlow(date: String): Flow<List<LogEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(entry: LogEntry)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLogs(entries: List<LogEntry>)

    @Query("DELETE FROM log_entries WHERE id = :id")
    suspend fun deleteLogById(id: String)

    @Query("DELETE FROM log_entries WHERE g = :goalId")
    suspend fun deleteLogsForGoal(goalId: String): Int
}
