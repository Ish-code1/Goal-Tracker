package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ConfettiOverlay
import com.example.ui.components.PillTabs
import com.example.ui.screens.GoalsScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.GoalTrackerViewModel
import com.example.util.GoalCalculations
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: GoalTrackerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsState()
            MyApplicationTheme(themeMode = themeMode) {
                GoalTrackerApp(viewModel)
            }
        }
    }
}

@Composable
fun GoalTrackerApp(viewModel: GoalTrackerViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current
    val currentTab by viewModel.tab.collectAsState()
    val goals by viewModel.goals.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val historyTasks by viewModel.historyTasks.collectAsState()

    val todayDate by viewModel.todayDate.collectAsState()
    val statsMode by viewModel.statsMode.collectAsState()
    val statsAnchor by viewModel.statsAnchor.collectAsState()
    val statsMetric by viewModel.statsMetric.collectAsState()
    val statsScope by viewModel.statsScope.collectAsState()
    val historyGrouping by viewModel.historyGrouping.collectAsState()
    val scoreGrouping by viewModel.scoreGrouping.collectAsState()

    val taskMode by viewModel.taskMode.collectAsState()
    val taskDeadline by viewModel.taskDeadline.collectAsState()
    val taskColor by viewModel.taskColor.collectAsState()
    val prefillGoal by viewModel.prefillGoal.collectAsState()

    val confettiTrigger by viewModel.confettiTrigger.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    // Handle back button: if not on "today", return to "today"
    BackHandler(enabled = currentTab != "today") {
        viewModel.setTab("today")
    }

    // Toast state
    var currentToastMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        viewModel.toastMessage.collect { msg ->
            currentToastMessage = msg
            delay(1800)
            if (currentToastMessage == msg) {
                currentToastMessage = null
            }
        }
    }

    // Dynamic accent color
    val activeAccentColor = remember(currentTab, goals, viewModel.selectedGoalId.collectAsState().value) {
        if (currentTab == "today" && goals.isNotEmpty()) {
            val selId = viewModel.selectedGoalId.value
            val g = goals.find { it.id == selId } ?: goals.first()
            GoalCalculations.parseHexColor(g.col)
        } else {
            DefaultAccent
        }
    }

    // Focus and Keyboard controllers
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Detect virtual keyboard open
    val isImeVisible = WindowInsets.ime.getBottom(density) > 0

    // Dismiss keyboard when tab changes
    LaunchedEffect(currentTab) {
        focusManager.clearFocus()
        keyboardController?.hide()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_screen"),
        containerColor = DarkBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Fixed Sticky Header: Brand + PillTabs at the top
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GOAL TRACKER",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 3.sp,
                            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Quick theme toggle button (Dark / Light / Midnight / Forest)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(DarkSurface2)
                                    .border(1.dp, DarkBorder, RoundedCornerShape(99.dp))
                                    .clickable {
                                        val modes = AppThemeMode.values()
                                        val nextIndex = (themeMode.ordinal + 1) % modes.size
                                        viewModel.setThemeMode(modes[nextIndex])
                                    }
                                    .padding(horizontal = 9.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = themeMode.icon, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = themeMode.displayName,
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // If keyboard is visible, provide an immediate one-tap dismiss button
                            if (isImeVisible) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(99.dp))
                                        .background(DarkSurface2)
                                        .border(1.dp, DarkBorder, RoundedCornerShape(99.dp))
                                        .clickable {
                                            focusManager.clearFocus()
                                            keyboardController?.hide()
                                        }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "Close Keyboard ✕",
                                            color = DefaultAccent,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                            }
                        }
                    }

                    // Top Sliding Pill Navigation Tabs
                    PillTabs(
                        selectedTab = currentTab,
                        onTabSelected = {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                            viewModel.setTab(it)
                        },
                        activeColor = activeAccentColor,
                        modifier = Modifier.testTag("pill_tabs")
                    )
                }

                // Smoothly Scrollable Screen Content
                key(currentTab) {
                    val scrollState = rememberScrollState()

                    // Automatically dismiss keyboard as soon as user starts scrolling
                    LaunchedEffect(scrollState.isScrollInProgress) {
                        if (scrollState.isScrollInProgress) {
                            focusManager.clearFocus()
                            keyboardController?.hide()
                        }
                    }

                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                                .padding(horizontal = 16.dp)
                        ) {
                            when (currentTab) {
                                "today" -> TodayScreen(
                                    viewModel = viewModel,
                                    goals = goals,
                                    logs = logs,
                                    selectedDate = todayDate
                                )
                                "goals" -> GoalsScreen(
                                    viewModel = viewModel,
                                    goals = goals,
                                    logs = logs,
                                    prefill = prefillGoal
                                )
                                "stats" -> StatsScreen(
                                    viewModel = viewModel,
                                    goals = goals,
                                    logs = logs,
                                    mode = statsMode,
                                    anchor = statsAnchor,
                                    metric = statsMetric,
                                    scope = statsScope,
                                    historyGrouping = historyGrouping,
                                    scoreGrouping = scoreGrouping
                                )
                                "tasks" -> TasksScreen(
                                    viewModel = viewModel,
                                    tasks = tasks,
                                    historyTasks = historyTasks,
                                    taskMode = taskMode,
                                    taskDeadline = taskDeadline,
                                    taskColor = taskColor
                                )
                                "notes" -> NotesScreen(
                                    viewModel = viewModel
                                )
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Footer sync notice
                            Text(
                                text = "100% Offline & Private · Saved locally on this device.",
                                color = TextMuted,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(start = 2.dp)
                            )

                            // Generous bottom spacer so content can slide down all the way comfortably
                            Spacer(modifier = Modifier.height(200.dp))
                        }
                    }
                }
            }

            // Confetti Overlay on top
            ConfettiOverlay(
                trigger = confettiTrigger,
                onFinished = {}
            )

            // Floating Pill Toast
            AnimatedVisibility(
                visible = currentToastMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 32.dp)
            ) {
                currentToastMessage?.let { msg ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(TextPrimary)
                            .padding(horizontal = 22.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = msg,
                            color = DarkBg,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}
