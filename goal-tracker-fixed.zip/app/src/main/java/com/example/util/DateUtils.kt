package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object DateUtils {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.US)

    fun todayDs(): String {
        return isoFormat.format(Date())
    }

    fun nowTime(): String {
        return timeFormat.format(Date())
    }

    fun pad(n: Int): String = if (n < 10) "0$n" else n.toString()

    fun parseDate(s: String): Calendar {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val parts = s.split("-")
        if (parts.size == 3) {
            val y = parts[0].toIntOrNull() ?: 2026
            val m = (parts[1].toIntOrNull() ?: 1) - 1
            val d = parts[2].toIntOrNull() ?: 1
            cal.set(y, m, d)
        }
        return cal
    }

    fun formatDate(cal: Calendar): String {
        return "${cal.get(Calendar.YEAR)}-${pad(cal.get(Calendar.MONTH) + 1)}-${pad(cal.get(Calendar.DAY_OF_MONTH))}"
    }

    fun addDays(dateStr: String, n: Int): String {
        val cal = parseDate(dateStr)
        cal.add(Calendar.DAY_OF_MONTH, n)
        return formatDate(cal)
    }

    fun yearMonth(s: String): String {
        return if (s.length >= 7) s.substring(0, 7) else s
    }

    // Days difference between two YYYY-MM-DD dates: Math.round((pd(b)-pd(a))/864e5)
    fun daysDiff(a: String, b: String): Int {
        val calA = parseDate(a)
        val calB = parseDate(b)
        val diffMillis = calB.timeInMillis - calA.timeInMillis
        return (diffMillis.toDouble() / 86400000.0).roundToInt()
    }

    // Week boundaries [Mon, Sun] matching HTML wk()
    fun weekRange(dateStr: String): Pair<String, String> {
        val cal = parseDate(dateStr)
        // In Java Calendar, Sunday=1, Monday=2, ... Saturday=7
        // JavaScript pd(a).getDay() -> Sun=0, Mon=1, ..., Sat=6
        // JS: ((day + 6) % 7) gives Mon=0, Tue=1, ... Sun=6
        val jsDay = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val monday = addDays(dateStr, -jsDay)
        val sunday = addDays(monday, 6)
        return Pair(monday, sunday)
    }

    // Month boundaries [firstDay, lastDay]
    fun monthRange(dateStr: String, monthOffset: Int = 0): Pair<String, String> {
        val cal = parseDate(dateStr)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, monthOffset)
        val firstDay = formatDate(cal)
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        val lastDay = formatDate(cal)
        return Pair(firstDay, lastDay)
    }

    // Formatted date string DD/MM/YYYY (fDM in HTML)
    fun formatDM(s: String): String {
        if (s.isEmpty()) return ""
        val parts = s.split("-")
        return if (parts.size == 3) "${parts[2]}/${parts[1]}/${parts[0]}" else s
    }

    // Formatted date "08-Oct-2026" (fD in HTML)
    fun formatD(dateStr: String): String {
        val cal = parseDate(dateStr)
        val df = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH)
        return df.format(cal.time)
    }

    // Formatted short "8 Oct" (L in HTML)
    fun formatShort(dateStr: String): String {
        val cal = parseDate(dateStr)
        val df = SimpleDateFormat("d MMM", Locale.ENGLISH)
        return df.format(cal.time)
    }

    // Formats duration minutes into "1h 30m" or "45m"
    fun formatHoursMinutes(minutes: Int): String {
        return if (minutes >= 60) {
            val h = minutes / 60
            val rem = minutes % 60
            if (rem > 0) "${h}h ${rem}m" else "${h}h"
        } else {
            "${minutes}m"
        }
    }

    fun round1(v: Double): Double {
        return (v * 10.0).roundToInt() / 10.0
    }

    fun formatNumber(v: Double): String {
        val rounded = (v * 10.0).roundToInt() / 10.0
        return if (rounded % 1.0 == 0.0) rounded.toLong().toString() else rounded.toString()
    }

    fun hoursFromMinutes(m: Int): Double {
        return (m / 6.0).roundToInt() / 10.0
    }
}
