package com.example.util

import androidx.compose.ui.graphics.Color
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class DayStats(val m: Int = 0, val u: Double = 0.0)

object GoalCalculations {
    val PALETTE = listOf(
        "#60a5fa", "#34d399", "#fb923c", "#f472b6",
        "#a78bfa", "#facc15", "#22d3ee", "#f87171"
    )

    fun parseHexColor(hex: String, default: Color = Color(0xFF60A5FA)): Color {
        return try {
            val clean = hex.removePrefix("#")
            val colorInt = when (clean.length) {
                6 -> 0xFF000000.toInt() or clean.toInt(16)
                8 -> clean.toLong(16).toInt()
                else -> return default
            }
            Color(colorInt)
        } catch (_: Exception) {
            default
        }
    }

    fun onColor(hex: String): Color {
        val clean = hex.removePrefix("#")
        return try {
            val n = clean.toInt(16)
            val r = (n shr 16) and 255
            val g = (n shr 8) and 255
            val b = n and 255
            val lum = 0.299 * r + 0.587 * g + 0.114 * b
            if (lum > 140) Color(0xFF06100B) else Color.White
        } catch (_: Exception) {
            Color.White
        }
    }

    fun eff(g: Goal): String {
        return if (!g.dn.isNullOrEmpty() && g.dn < g.e) g.dn else g.e
    }

    fun dys(g: Goal): Int {
        return max(1, DateUtils.daysDiff(g.s, g.e) + 1)
    }

    fun overlap(g: Goal, a: String, b: String): Int {
        val effectiveEnd = eff(g)
        val start = if (a > g.s) a else g.s
        val end = if (b < effectiveEnd) b else effectiveEnd
        if (start > end) return 0
        return max(0, DateUtils.daysDiff(start, end) + 1)
    }

    fun dh(g: Goal): Double {
        return if (g.th > 0) g.th else if (g.totalHours > 0) g.totalHours / dys(g) else 0.0
    }

    fun du(g: Goal): Double {
        return if (g.tu > 0) g.tu else if (g.totalCount > 0) g.totalCount / dys(g) else 0.0
    }

    fun totH(g: Goal): Double {
        // Use total hours if mentioned; only fallback to hr * days when total hours not mentioned
        return if (g.totalHours > 0) g.totalHours else (g.th * dys(g))
    }

    fun totU(g: Goal): Double {
        // Use total count if mentioned; only fallback to units * days when total count not mentioned
        return if (g.totalCount > 0) g.totalCount else (g.tu * dys(g))
    }

    fun periodTarget(g: Goal, metric: String, a: String, b: String): Double {
        val total = if (metric == "m") g.totalHours else g.totalCount
        val ov = overlap(g, a, b)
        if (ov <= 0) return 0.0
        // If total is mentioned (> 0), distribute from total across the days
        // Only if total target is not mentioned, fallback to daily units * days (or daily hr * days)
        return if (total > 0) {
            total * ov / dys(g)
        } else {
            val dailyFallback = if (metric == "m") g.th else g.tu
            dailyFallback * ov
        }
    }

    fun adjustGoals(goals: List<Goal>, logs: List<LogEntry>): List<Goal> {
        val earliestMap = logs.groupBy { it.g }.mapValues { (_, l) -> l.minOf { it.d } }
        return goals.map { g ->
            val earliest = earliestMap[g.id]
            if (earliest != null && earliest < g.s) g.copy(s = earliest) else g
        }
    }

    fun isGoalActiveOnDay(g: Goal, date: String, agg: Map<String, Map<String, DayStats>>): Boolean {
        val goalAgg = agg[g.id]
        val hasLogOnDay = goalAgg?.containsKey(date) == true
        return (date >= g.s || hasLogOnDay) && (g.dn == null || date <= g.dn) && (date <= g.e || hasLogOnDay)
    }

    fun aggregate(entries: List<LogEntry>): Map<String, Map<String, DayStats>> {
        val result = mutableMapOf<String, MutableMap<String, DayStats>>()
        for (e in entries) {
            val goalMap = result.getOrPut(e.g) { mutableMapOf() }
            val current = goalMap[e.d] ?: DayStats()
            goalMap[e.d] = DayStats(
                m = current.m + e.m,
                u = current.u + e.u
            )
        }
        return result
    }

    fun comp(g: Goal, stats: DayStats?): Double {
        val fractions = mutableListOf<Double>()
        val dailyH = dh(g)
        if (dailyH > 0) {
            val hours = (stats?.m ?: 0) / 60.0
            fractions.add(min(1.0, hours / dailyH))
        }
        val dailyU = du(g)
        if (dailyU > 0) {
            val units = stats?.u ?: 0.0
            fractions.add(min(1.0, units / dailyU))
        }
        return if (fractions.isNotEmpty()) {
            fractions.sum() / fractions.size
        } else {
            if (stats != null && (stats.m > 0 || stats.u > 0)) 1.0 else 0.0
        }
    }

    fun completionForDay(
        goals: List<Goal>,
        date: String,
        agg: Map<String, Map<String, DayStats>>
    ): Double? {
        val activeGoals = goals.filter { isGoalActiveOnDay(it, date, agg) }
        if (activeGoals.isEmpty()) return null
        val values = activeGoals.map { g ->
            val stats = agg[g.id]?.get(date)
            comp(g, stats)
        }
        return values.sum() / values.size
    }

    fun streak(allLogs: List<LogEntry>, today: String): Int {
        val datesWithLogs = allLogs.map { it.d }.toSet()
        var current = if (datesWithLogs.contains(today)) today else DateUtils.addDays(today, -1)
        var count = 0
        while (datesWithLogs.contains(current)) {
            count++
            current = DateUtils.addDays(current, -1)
        }
        return count
    }

    fun longestStreak(allLogs: List<LogEntry>): Int {
        val uniqueSorted = allLogs.map { it.d }.distinct().sorted()
        var best = 0
        var current = 0
        var prev: String? = null
        for (d in uniqueSorted) {
            current = if (prev != null && DateUtils.addDays(prev, 1) == d) current + 1 else 1
            if (current > best) best = current
            prev = d
        }
        return best
    }

    fun xpOf(allLogs: List<LogEntry>): Int {
        var totalM = 0
        var totalU = 0.0
        for (e in allLogs) {
            totalM += e.m
            totalU += e.u
        }
        return (totalM / 6.0 + totalU * 5.0).roundToInt()
    }

    fun levelOf(xp: Int): Int {
        return floor(sqrt(xp / 50.0)).toInt() + 1
    }

    // Gaussian Error function
    fun erf(x: Double): Double {
        val s = if (x >= 0) 1.0 else -1.0
        val ax = abs(x)
        val t = 1.0 / (1.0 + 0.3275911 * ax)
        val poly = ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t
        return s * (1.0 - poly * exp(-ax * ax))
    }

    fun phi(z: Double): Double {
        return 0.5 * (1.0 + erf(z / sqrt(2.0)))
    }
}
