package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.util.GoalCalculations

val EXTENDED_PALETTE = listOf(
    "#60a5fa", "#34d399", "#fb923c", "#f472b6",
    "#a78bfa", "#facc15", "#22d3ee", "#f87171",
    "#818cf8", "#4ade80", "#e879f9", "#38bdf8",
    "#fbbf24", "#f43f5e", "#10b981", "#a855f7"
)

val RAINBOW_BRUSH = Brush.sweepGradient(
    listOf(
        Color(0xFFF87171),
        Color(0xFFFACC15),
        Color(0xFF34D399),
        Color(0xFF22D3EE),
        Color(0xFFA78BFA),
        Color(0xFFF472B6),
        Color(0xFFF87171)
    )
)

@Composable
fun ColorPalettePicker(
    selectedColor: String,
    onColorSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showColorBoxDialog by remember { mutableStateOf(false) }
    var showCustomRgbDialog by remember { mutableStateOf(false) }

    val currentColor = GoalCalculations.parseHexColor(selectedColor)
    val defaultThree = listOf("#60a5fa", "#34d399", "#fb923c")
    val visibleColors = remember(selectedColor) {
        if (defaultThree.any { it.equals(selectedColor, ignoreCase = true) } || selectedColor.isBlank()) {
            defaultThree
        } else {
            listOf(defaultThree[0], defaultThree[1], selectedColor)
        }
    }

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // 3 visible colors
        visibleColors.forEach { hex ->
            val col = GoalCalculations.parseHexColor(hex)
            val isSelected = hex.equals(selectedColor, ignoreCase = true)

            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(col)
                    .border(
                        width = if (isSelected) 2.5.dp else 1.dp,
                        color = if (isSelected) TextPrimary else DarkBorder,
                        shape = CircleShape
                    )
                    .clickable { onColorSelected(hex) },
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Text(
                        text = "✓",
                        color = GoalCalculations.onColor(hex),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Small box trigger button: opens all rest colours in modal dialog
        val isSelectedOutsideDefault = !defaultThree.any { it.equals(selectedColor, ignoreCase = true) } && selectedColor.isNotBlank()
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(DarkSurface2)
                .border(
                    width = 1.dp,
                    color = if (isSelectedOutsideDefault) currentColor else DarkBorder,
                    shape = RoundedCornerShape(6.dp)
                )
                .clickable { showColorBoxDialog = true },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "+",
                color = if (isSelectedOutsideDefault) currentColor else TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }

    // Small Box Modal showing all colors in neat grid + custom RGB picker button
    if (showColorBoxDialog) {
        Dialog(onDismissRequest = { showColorBoxDialog = false }) {
            Box(
                modifier = Modifier
                    .width(300.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkCard)
                    .border(1.dp, DarkBorder, RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Choose Colour",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "✕",
                            color = TextMuted,
                            fontSize = 16.sp,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable { showColorBoxDialog = false }
                                .padding(4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4x4 Grid of swatches
                    val chunks = EXTENDED_PALETTE.chunked(4)
                    chunks.forEach { rowColors ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            rowColors.forEach { hex ->
                                val color = GoalCalculations.parseHexColor(hex)
                                val isSelected = hex.equals(selectedColor, ignoreCase = true)

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (isSelected) 3.dp else 1.dp,
                                            color = if (isSelected) TextPrimary else DarkBorder,
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onColorSelected(hex)
                                            showColorBoxDialog = false
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSelected) {
                                        Text(
                                            text = "✓",
                                            color = GoalCalculations.onColor(hex),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Custom Colour Button with RGB spectrum icon
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurface2)
                            .clickable {
                                showColorBoxDialog = false
                                showCustomRgbDialog = true
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(RAINBOW_BRUSH)
                        )
                        Text(
                            text = "Custom Colour (RGB / HEX)…",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }

    if (showCustomRgbDialog) {
        CustomColorPickerDialog(
            initialHex = selectedColor,
            onDismissRequest = { showCustomRgbDialog = false },
            onColorConfirmed = { hex ->
                onColorSelected(hex)
                showCustomRgbDialog = false
            }
        )
    }
}

@Composable
fun CustomColorPickerDialog(
    initialHex: String,
    onDismissRequest: () -> Unit,
    onColorConfirmed: (String) -> Unit
) {
    val initialColor = remember(initialHex) { GoalCalculations.parseHexColor(initialHex) }
    var red by remember { mutableFloatStateOf(initialColor.red) }
    var green by remember { mutableFloatStateOf(initialColor.green) }
    var blue by remember { mutableFloatStateOf(initialColor.blue) }

    val currentColor = Color(red, green, blue)
    val hexString = String.format("#%02X%02X%02X", (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())

    Dialog(onDismissRequest = onDismissRequest) {
        Box(
            modifier = Modifier
                .width(320.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(DarkCard)
                .border(1.dp, DarkBorder, RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Custom Colour",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Color Preview Box with Hex label
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(currentColor)
                        .border(3.dp, DarkBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = hexString,
                        color = GoalCalculations.onColor(hexString),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Red Slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("R", color = Color(0xFFF87171), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.width(20.dp))
                    Slider(
                        value = red,
                        onValueChange = { red = it },
                        colors = SliderDefaults.colors(thumbColor = Color(0xFFF87171), activeTrackColor = Color(0xFFF87171)),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${(red * 255).toInt()}", color = TextMuted, fontSize = 11.sp, modifier = Modifier.width(32.dp))
                }

                // Green Slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("G", color = Color(0xFF34D399), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.width(20.dp))
                    Slider(
                        value = green,
                        onValueChange = { green = it },
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF34D399), activeTrackColor = Color(0xFF34D399)),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${(green * 255).toInt()}", color = TextMuted, fontSize = 11.sp, modifier = Modifier.width(32.dp))
                }

                // Blue Slider
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("B", color = Color(0xFF60A5FA), fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.width(20.dp))
                    Slider(
                        value = blue,
                        onValueChange = { blue = it },
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF60A5FA), activeTrackColor = Color(0xFF60A5FA)),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${(blue * 255).toInt()}", color = TextMuted, fontSize = 11.sp, modifier = Modifier.width(32.dp))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text("Cancel", color = TextMuted)
                    }

                    Button(
                        onClick = { onColorConfirmed(hexString) },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = currentColor,
                            contentColor = GoalCalculations.onColor(hexString)
                        )
                    ) {
                        Text("Select Colour", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
