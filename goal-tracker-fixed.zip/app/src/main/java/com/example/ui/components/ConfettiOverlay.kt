package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.example.util.GoalCalculations
import kotlin.math.sin
import kotlin.random.Random

data class ConfettiPiece(
    val startXRatio: Float,
    val color: Color,
    val driftX: Float,
    val fallSpeed: Float,
    val delay: Float,
    val widthPx: Float,
    val heightPx: Float,
    val rotationSpeed: Float,
    val shapeType: Int // 0 = rect, 1 = circle, 2 = ribbon
)

@Composable
fun ConfettiOverlay(
    trigger: Long,
    onFinished: () -> Unit = {}
) {
    if (trigger <= 0L) return

    val density = LocalDensity.current
    var isVisible by remember(trigger) { mutableStateOf(true) }
    val animProgress = remember(trigger) { Animatable(0f) }

    val pieces = remember(trigger, density) {
        val random = Random(trigger)
        val palette = listOf(
            "#60a5fa", "#34d399", "#fb923c", "#f472b6",
            "#a78bfa", "#facc15", "#22d3ee", "#f87171",
            "#4ade80", "#e879f9", "#38bdf8", "#fbbf24",
            "#ffffff", "#fef08a", "#6ee7b7", "#93c5fd"
        )

        val minW = with(density) { 9.dp.toPx() }
        val maxW = with(density) { 18.dp.toPx() }
        val minH = with(density) { 12.dp.toPx() }
        val maxH = with(density) { 26.dp.toPx() }
        val driftRange = with(density) { 320.dp.toPx() }

        List(120) { i ->
            val colHex = palette[i % palette.size]
            val w = minW + random.nextFloat() * (maxW - minW)
            val h = minH + random.nextFloat() * (maxH - minH)
            ConfettiPiece(
                startXRatio = 0.05f + random.nextFloat() * 0.90f,
                color = GoalCalculations.parseHexColor(colHex),
                driftX = (random.nextFloat() - 0.5f) * driftRange,
                fallSpeed = 0.85f + random.nextFloat() * 0.45f,
                delay = random.nextFloat() * 0.22f,
                widthPx = w,
                heightPx = h,
                rotationSpeed = 360f + random.nextFloat() * 720f,
                shapeType = i % 3
            )
        }
    }

    LaunchedEffect(trigger) {
        isVisible = true
        animProgress.snapTo(0f)
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 3200, easing = LinearEasing)
        )
        isVisible = false
        onFinished()
    }

    if (isVisible) {
        val p = animProgress.value
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            pieces.forEach { piece ->
                val localProg = ((p - piece.delay) / (1f - piece.delay)).coerceIn(0f, 1f)
                if (localProg > 0f) {
                    val flutterX = sin(localProg * 12.0 + piece.startXRatio * 10.0).toFloat() * 15f
                    val x = piece.startXRatio * w + piece.driftX * localProg + flutterX

                    // Upward burst then graceful cascade
                    val initialLift = -180f * (1f - localProg).coerceAtLeast(0f)
                    val y = -60f + (h + 120f) * (localProg * piece.fallSpeed) + initialLift
                    val rot = localProg * piece.rotationSpeed

                    val alpha = if (localProg > 0.82f) (1f - localProg) / 0.18f else 1f

                    if (y < h + 100f && alpha > 0.01f) {
                        rotate(degrees = rot, pivot = Offset(x, y)) {
                            when (piece.shapeType) {
                                1 -> {
                                    drawCircle(
                                        color = piece.color.copy(alpha = alpha),
                                        radius = piece.widthPx / 2f,
                                        center = Offset(x, y)
                                    )
                                }
                                2 -> {
                                    // Ribbon / pill
                                    drawRoundRect(
                                        color = piece.color.copy(alpha = alpha),
                                        topLeft = Offset(x - piece.widthPx / 2f, y - piece.heightPx / 2f),
                                        size = Size(piece.widthPx * 0.7f, piece.heightPx * 1.3f),
                                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                                    )
                                }
                                else -> {
                                    drawRect(
                                        color = piece.color.copy(alpha = alpha),
                                        topLeft = Offset(x - piece.widthPx / 2f, y - piece.heightPx / 2f),
                                        size = Size(piece.widthPx, piece.heightPx)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
