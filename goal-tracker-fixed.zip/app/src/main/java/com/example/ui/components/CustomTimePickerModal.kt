package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.util.DateUtils

@Composable
fun CustomTimePickerModal(
    initialTime: String, // HH:mm or empty
    onDismissRequest: () -> Unit,
    onTimeSelected: (String) -> Unit
) {
    val initialHours = remember(initialTime) {
        val parts = initialTime.split(":")
        if (parts.size >= 2) parts[0].toIntOrNull() ?: 9 else 9
    }
    val initialMinutes = remember(initialTime) {
        val parts = initialTime.split(":")
        if (parts.size >= 2) parts[1].toIntOrNull() ?: 0 else 0
    }

    var selectedHour by remember { mutableIntStateOf(initialHours) }
    var selectedMinute by remember { mutableIntStateOf(initialMinutes) }

    Dialog(onDismissRequest = onDismissRequest) {
        Box(
            modifier = Modifier
                .width(300.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(DarkCard)
                .border(1.dp, DarkBorder, RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Select Time",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hour picker buttons
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "▲",
                            color = TextMuted,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedHour = (selectedHour + 1) % 24
                                }
                                .padding(8.dp)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurface2)
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = DateUtils.pad(selectedHour),
                                color = DefaultAccent,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "▼",
                            color = TextMuted,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedHour = if (selectedHour == 0) 23 else selectedHour - 1
                                }
                                .padding(8.dp)
                        )
                    }

                    Text(
                        text = ":",
                        color = TextPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    // Minute picker buttons (in steps of 5 for convenience or 1)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "▲",
                            color = TextMuted,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedMinute = (selectedMinute + 5) % 60
                                }
                                .padding(8.dp)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurface2)
                                .padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = DateUtils.pad(selectedMinute),
                                color = DefaultAccent,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "▼",
                            color = TextMuted,
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedMinute = if (selectedMinute < 5) 55 else selectedMinute - 5
                                }
                                .padding(8.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = {
                        onTimeSelected("")
                        onDismissRequest()
                    }) {
                        Text("Clear", color = TextMuted)
                    }

                    Row {
                        TextButton(onClick = onDismissRequest) {
                            Text("Cancel", color = TextMuted)
                        }
                        TextButton(onClick = {
                            val timeStr = "${DateUtils.pad(selectedHour)}:${DateUtils.pad(selectedMinute)}"
                            onTimeSelected(timeStr)
                            onDismissRequest()
                        }) {
                            Text("OK", color = DefaultAccent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
