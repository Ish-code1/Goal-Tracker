package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

data class FreqColumn(
    val label: String,
    val dates: List<String?> // 7 elements for Mon..Sun
)

@Composable
fun WeekdayFrequencyMatrix(
    columns: List<FreqColumn>,
    rowIndices: List<Int>, // 0..6 for Mon..Sun
    completionLookup: (String) -> Double?,
    todayDate: String,
    accentColor: Color = DefaultAccent,
    modifier: Modifier = Modifier
) {
    val weekDays = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    Column(modifier = modifier.fillMaxWidth()) {
        // Header Row: [empty 34dp] [col labels...] [Days]
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(modifier = Modifier.width(34.dp))
            columns.forEach { col ->
                Text(
                    text = col.label,
                    modifier = Modifier.weight(1f),
                    color = TextMuted,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
            Text(
                text = "Days",
                modifier = Modifier.width(40.dp),
                color = TextMuted,
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }

        // Rows for each weekday
        rowIndices.forEach { w ->
            var activeDaysCount = 0

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Weekday label
                Text(
                    text = weekDays[w],
                    modifier = Modifier.width(34.dp),
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )

                // Circles across columns
                columns.forEach { col ->
                    val d = col.dates.getOrNull(w)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (d != null) {
                            val v = completionLookup(d)
                            val isActive = v != null && v > 0
                            if (isActive) activeDaysCount++

                            val circleSize = if (isActive) {
                                (8 + 14 * v!!.toFloat().coerceIn(0f, 1f)).dp
                            } else {
                                4.dp
                            }

                            val alpha = if (isActive) {
                                (0.4f + 0.6f * v!!.toFloat().coerceIn(0f, 1f))
                            } else {
                                0.2f
                            }

                            val isToday = d == todayDate

                            Box(
                                modifier = Modifier
                                    .size(circleSize)
                                    .clip(CircleShape)
                                    .background(accentColor.copy(alpha = alpha))
                                    .then(
                                        if (isToday) {
                                            Modifier.border(2.dp, TextPrimary, CircleShape)
                                        } else {
                                            Modifier
                                        }
                                    )
                            )
                        }
                    }
                }

                // Active days count
                Text(
                    text = activeDaysCount.toString(),
                    modifier = Modifier.width(40.dp),
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
