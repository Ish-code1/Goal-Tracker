package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun DonutChart(
    slices: List<Pair<Double, Color>>, // value and color
    total: Double,
    centerTitle: String,
    centerSubtitle: String,
    modifier: Modifier = Modifier,
    sizeDp: Dp? = null
) {
    val boxModifier = if (sizeDp != null) {
        modifier.size(sizeDp)
    } else {
        modifier.aspectRatio(1f)
    }

    Box(
        modifier = boxModifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val strokeWidth = (size.minDimension * 0.20f).coerceIn(12f, 38f)
            val radius = (size.minDimension - strokeWidth) / 2
            val centerOffset = center

            // Base track
            drawCircle(
                color = DarkBorder,
                radius = radius,
                center = centerOffset,
                style = Stroke(width = strokeWidth)
            )

            if (total > 0) {
                var startAngle = -90f
                slices.forEach { (value, color) ->
                    if (value > 0) {
                        val sweep = ((value / total) * 360f).toFloat().coerceAtMost(360f)
                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = sweep,
                            useCenter = false,
                            topLeft = Offset(centerOffset.x - radius, centerOffset.y - radius),
                            size = Size(radius * 2, radius * 2),
                            style = Stroke(width = strokeWidth)
                        )
                        startAngle += sweep
                    }
                }
            }
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = centerTitle,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = centerSubtitle,
                color = TextMuted,
                fontSize = 10.sp,
                maxLines = 1
            )
        }
    }
}
