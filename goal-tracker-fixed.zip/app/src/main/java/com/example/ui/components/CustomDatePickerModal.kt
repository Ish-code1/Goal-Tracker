package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.util.DateUtils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CustomDatePickerModal(
    initialDate: String,
    onDismissRequest: () -> Unit,
    onDateSelected: (String) -> Unit
) {
    val initialCal = remember(initialDate) { DateUtils.parseDate(initialDate) }
    var currentYear by remember { mutableIntStateOf(initialCal.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableIntStateOf(initialCal.get(Calendar.MONTH)) }

    val todayStr = DateUtils.todayDs()

    Dialog(onDismissRequest = onDismissRequest) {
        Box(
            modifier = Modifier
                .width(330.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(DarkCard)
                .border(1.dp, DarkBorder, RoundedCornerShape(22.dp))
                .padding(18.dp)
        ) {
            Column {
                // Header with navigation
                val displayCal = remember(currentYear, currentMonth) {
                    Calendar.getInstance().apply {
                        set(Calendar.YEAR, currentYear)
                        set(Calendar.MONTH, currentMonth)
                        set(Calendar.DAY_OF_MONTH, 1)
                    }
                }
                val monthTitle = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(displayCal.time)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (currentMonth == 0) {
                                currentMonth = 11
                                currentYear--
                            } else {
                                currentMonth--
                            }
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("‹", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = monthTitle,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    IconButton(
                        onClick = {
                            if (currentMonth == 11) {
                                currentMonth = 0
                                currentYear++
                            } else {
                                currentMonth++
                            }
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("›", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Weekday letters: M T W T F S S
                val weekLabels = listOf("M", "T", "W", "T", "F", "S", "S")
                Row(modifier = Modifier.fillMaxWidth()) {
                    weekLabels.forEach { label ->
                        Text(
                            text = label,
                            modifier = Modifier.weight(1f),
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Days grid
                // Offset: Monday = 0 ... Sunday = 6
                val firstDayOfWeek = (displayCal.get(Calendar.DAY_OF_WEEK) + 5) % 7
                val daysInMonth = displayCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                val totalCells = firstDayOfWeek + daysInMonth
                val totalRows = (totalCells + 6) / 7

                for (rowIndex in 0 until totalRows) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        for (colIndex in 0..6) {
                            val cellIndex = rowIndex * 7 + colIndex
                            val dayNum = cellIndex - firstDayOfWeek + 1
                            if (cellIndex < firstDayOfWeek || dayNum > daysInMonth) {
                                Spacer(modifier = Modifier.weight(1f))
                            } else {
                                val dateStr = "${currentYear}-${DateUtils.pad(currentMonth + 1)}-${DateUtils.pad(dayNum)}"
                                val isSelected = dateStr == initialDate
                                val isToday = dateStr == todayStr

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) DefaultAccent else Color.Transparent)
                                        .then(
                                            if (isToday && !isSelected) {
                                                Modifier.border(1.dp, DefaultAccent, RoundedCornerShape(10.dp))
                                            } else {
                                                Modifier
                                            }
                                        )
                                        .clickable {
                                            onDateSelected(dateStr)
                                            onDismissRequest()
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = dayNum.toString(),
                                        color = if (isSelected) Color(0xFF06100B) else TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom row: Today and Close buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = {
                            onDateSelected(todayStr)
                            onDismissRequest()
                        }
                    ) {
                        Text("Today", color = DefaultAccent, fontWeight = FontWeight.Bold)
                    }

                    TextButton(onClick = onDismissRequest) {
                        Text("Close", color = TextMuted)
                    }
                }
            }
        }
    }
}
