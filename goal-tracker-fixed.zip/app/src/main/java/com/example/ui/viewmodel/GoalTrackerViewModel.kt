package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.data.model.Task
import com.example.data.repository.GoalTrackerRepository
import com.example.ui.theme.AppThemeMode
import com.example.util.DateUtils
import com.example.util.GoalCalculations
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class GoalPrefill(
    val name: String,
    val col: String,
    val e: String
)

class GoalTrackerViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("goal_tracker_prefs", android.content.Context.MODE_PRIVATE)

    private val repository: GoalTrackerRepository = GoalTrackerRepository(
        AppDatabase.getInstance(application)
    )

    private val _themeMode = MutableStateFlow(
        run {
            val saved = prefs.getString("theme_mode", AppThemeMode.DARK.id) ?: AppThemeMode.DARK.id
            AppThemeMode.values().find { it.id == saved } ?: AppThemeMode.DARK
        }
    )
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode.id).apply()
    }

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    val goals: StateFlow<List<Goal>> = repository.goalsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<LogEntry>> = repository.logsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val allTasks: StateFlow<List<Task>> = repository.tasksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active tasks (shown in the lists) and removed ones (shown in History)
    val tasks: StateFlow<List<Task>> = allTasks
        .map { list -> list.filter { !it.hist } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val historyTasks: StateFlow<List<Task>> = allTasks
        .map { list -> list.filter { it.hist } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Deadline sort order in Tasks tab - remembered after the app closes
    private val _taskSortFarthest = MutableStateFlow(prefs.getBoolean("task_sort_farthest", true))
    val taskSortFarthest: StateFlow<Boolean> = _taskSortFarthest.asStateFlow()

    fun toggleTaskSort() {
        val next = !_taskSortFarthest.value
        _taskSortFarthest.value = next
        prefs.edit().putBoolean("task_sort_farthest", next).apply()
    }

    private val _tab = MutableStateFlow("today")
    val tab: StateFlow<String> = _tab.asStateFlow()

    private val _todayDate = MutableStateFlow(DateUtils.todayDs())
    val todayDate: StateFlow<String> = _todayDate.asStateFlow()

    // Selected goal ID for logging in Today tab
    private val _selectedGoalId = MutableStateFlow("")
    val selectedGoalId: StateFlow<String> = _selectedGoalId.asStateFlow()

    // Time input mode in Today tab: "m" (minutes) or "h" (hours)
    private val _timeInputUnit = MutableStateFlow("m")
    val timeInputUnit: StateFlow<String> = _timeInputUnit.asStateFlow()

    // Stats tab state
    private val _statsMode = MutableStateFlow("week") // "day", "week", "month"
    val statsMode: StateFlow<String> = _statsMode.asStateFlow()

    private val _statsAnchor = MutableStateFlow(DateUtils.todayDs())
    val statsAnchor: StateFlow<String> = _statsAnchor.asStateFlow()

    private val _statsMetric = MutableStateFlow("m") // "m" (Hours) or "u" (Count)
    val statsMetric: StateFlow<String> = _statsMetric.asStateFlow()

    private val _statsScope = MutableStateFlow("all") // "all" or goal ID
    val statsScope: StateFlow<String> = _statsScope.asStateFlow()

    private val _historyGrouping = MutableStateFlow("d") // "d", "w", "m"
    val historyGrouping: StateFlow<String> = _historyGrouping.asStateFlow()

    private val _scoreGrouping = MutableStateFlow("d") // "d", "w", "m"
    val scoreGrouping: StateFlow<String> = _scoreGrouping.asStateFlow()

    // Tasks tab creation state
    private val _taskMode = MutableStateFlow("d") // "d" (Deadline) or "l" (Long-term)
    val taskMode: StateFlow<String> = _taskMode.asStateFlow()

    private val _taskDeadline = MutableStateFlow(DateUtils.todayDs())
    val taskDeadline: StateFlow<String> = _taskDeadline.asStateFlow()

    private val _taskColor = MutableStateFlow(GoalCalculations.PALETTE[0])
    val taskColor: StateFlow<String> = _taskColor.asStateFlow()

    // Task to Goal conversion prefill
    private val _prefillGoal = MutableStateFlow<GoalPrefill?>(null)
    val prefillGoal: StateFlow<GoalPrefill?> = _prefillGoal.asStateFlow()
    private var prefillTaskId: String? = null

    // Toast and confetti triggers
    private val _toastMessage = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val toastMessage = _toastMessage.asSharedFlow()

    private val _confettiTrigger = MutableStateFlow(0L)
    val confettiTrigger: StateFlow<Long> = _confettiTrigger.asStateFlow()

    private var confettiCounter = 0L

    fun showToast(msg: String) {
        _toastMessage.tryEmit(msg)
    }

    fun fireConfetti() {
        confettiCounter++
        _confettiTrigger.value = System.currentTimeMillis() + confettiCounter
    }

    fun setTab(newTab: String) {
        if (newTab != "goals") {
            prefillTaskId = null
        }
        _tab.value = newTab
    }

    fun setTodayDate(date: String) {
        _todayDate.value = date
        _statsAnchor.value = date
    }

    fun setSelectedGoalId(id: String) {
        _selectedGoalId.value = id
    }

    fun setTimeInputUnit(unit: String) {
        _timeInputUnit.value = unit
    }

    fun logSession(
        goalId: String,
        minutes: Int,
        count: Double,
        note: String,
        startTime: String,
        endTime: String
    ) {
        if (minutes <= 0 && count <= 0.0) {
            showToast("Enter time or count")
            return
        }
        if (goals.value.find { it.id == goalId }?.dn != null) {
            showToast("Goal is completed - reopen it to log more")
            return
        }

        val allLogsBefore = logs.value
        val xpBefore = GoalCalculations.xpOf(allLogsBefore)
        val levelBefore = GoalCalculations.levelOf(xpBefore)

        val newEntry = LogEntry(
            id = UUID.randomUUID().toString().take(8),
            d = _todayDate.value,
            g = goalId,
            m = minutes,
            u = count,
            n = note.trim(),
            t = startTime,
            t2 = endTime
        )

        viewModelScope.launch {
            val goal = goals.value.find { it.id == goalId }
            if (goal != null && _todayDate.value < goal.s) {
                repository.updateGoal(goal.copy(s = _todayDate.value))
            }
            repository.insertLog(newEntry)
            _selectedGoalId.value = goalId
            _statsAnchor.value = _todayDate.value

            val allLogsAfter = allLogsBefore + newEntry
            val xpAfter = GoalCalculations.xpOf(allLogsAfter)
            val levelAfter = GoalCalculations.levelOf(xpAfter)

            val currentGoal = goals.value.find { it.id == goalId }
            val agg = GoalCalculations.aggregate(allLogsAfter)
            val goalStats = agg[goalId]?.get(_todayDate.value)
            val comp = if (currentGoal != null) GoalCalculations.comp(currentGoal, goalStats) else 0.0

            val dh = if (currentGoal != null) GoalCalculations.dh(currentGoal) else 0.0
            val du = if (currentGoal != null) GoalCalculations.du(currentGoal) else 0.0
            val hoursDone = (goalStats?.m ?: 0) / 60.0
            val unitsDone = goalStats?.u ?: 0.0
            val targetReached = (comp >= 0.999 && (dh > 0 || du > 0)) ||
                    (dh > 0 && hoursDone >= dh) ||
                    (du > 0 && unitsDone >= du)

            // Always celebrate with confetti for positive reinforcement
            fireConfetti()

            if (levelAfter > levelBefore) {
                showToast("Level up! Lv $levelAfter 🎉")
            } else if (targetReached) {
                showToast("Target smashed! 🎯")
            } else {
                val gainedXp = (minutes / 6.0 + count * 5.0).toInt().coerceAtLeast(10)
                showToast("Logged! +$gainedXp XP ✨")
            }
        }
    }

    fun deleteLog(id: String) {
        viewModelScope.launch {
            repository.deleteLog(id)
        }
    }

    fun addGoal(
        name: String,
        deadline: String,
        startSlot: String,
        endSlot: String,
        hoursPerDay: Double,
        totalHours: Double,
        countPerDay: Double,
        totalCount: Double,
        units: String,
        colorHex: String
    ) {
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) {
            showToast("Name the goal")
            return
        }
        val today = DateUtils.todayDs()
        if (deadline <= today) {
            showToast("Deadline must be a future date")
            return
        }
        val hasWs = startSlot.isNotEmpty()
        val hasWe = endSlot.isNotEmpty()
        if (hasWs != hasWe) {
            showToast("Set both slot times, or leave both blank")
            return
        }

        val newGoal = Goal(
            id = UUID.randomUUID().toString().take(8),
            name = trimmedName,
            s = today,
            e = deadline,
            ws = startSlot,
            we = endSlot,
            th = hoursPerDay,
            tu = countPerDay,
            totalHours = totalHours,
            totalCount = totalCount,
            un = units.trim().ifEmpty { "units" },
            col = colorHex
        )

        viewModelScope.launch {
            repository.insertGoal(newGoal)
            prefillTaskId?.let { taskId ->
                repository.deleteTask(taskId)
                prefillTaskId = null
            }
            _prefillGoal.value = null
            showToast("Goal added")
        }
    }

    fun updateGoal(goal: Goal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
        }
    }

    fun setGoalCompleted(goalId: String, completed: Boolean) {
        val goal = goals.value.find { it.id == goalId } ?: return
        val updated = if (completed) {
            goal.copy(dn = DateUtils.todayDs(), dt = DateUtils.nowTime())
        } else {
            goal.copy(dn = null, dt = null)
        }
        viewModelScope.launch {
            repository.updateGoal(updated)
            if (completed) {
                fireConfetti()
                showToast("Goal marked completed")
            } else {
                showToast("Goal reopened")
            }
        }
    }

    fun resetGoalData(goalId: String) {
        viewModelScope.launch {
            val count = repository.clearGoalLogs(goalId)
            showToast("$count entr${if (count == 1) "y" else "ies"} cleared")
        }
    }

    fun deleteGoal(goalId: String) {
        viewModelScope.launch {
            repository.deleteGoal(goalId)
            showToast("Goal deleted")
        }
    }

    fun setGoalColor(goalId: String, color: String) {
        val goal = goals.value.find { it.id == goalId } ?: return
        updateGoal(goal.copy(col = color))
        showToast("Colour changed")
    }

    // Task actions
    fun setTaskMode(mode: String) {
        _taskMode.value = mode
    }

    fun setTaskDeadline(d: String) {
        _taskDeadline.value = d
    }

    fun setTaskColor(c: String) {
        _taskColor.value = c
    }

    fun addTask(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            showToast("Name the task")
            return
        }
        val isLongTerm = _taskMode.value == "l"
        val deadline = if (isLongTerm) "" else _taskDeadline.value
        val currentColor = _taskColor.value
        val newTask = Task(
            id = UUID.randomUUID().toString().take(8),
            name = trimmed,
            d = deadline,
            col = currentColor,
            done = false
        )
        viewModelScope.launch {
            repository.insertTask(newTask)
            // Cycle to the next color in the palette for the next activity
            val palette = GoalCalculations.PALETTE
            val currentIndex = palette.indexOfFirst { it.equals(currentColor, ignoreCase = true) }
            val nextIndex = if (currentIndex >= 0) (currentIndex + 1) % palette.size else 0
            _taskColor.value = palette[nextIndex]
        }
    }

    fun toggleTask(taskId: String) {
        val task = tasks.value.find { it.id == taskId } ?: return
        viewModelScope.launch {
            repository.updateTask(task.copy(done = !task.done))
        }
    }

    // Done tasks go to History; tasks that are not done are deleted
    fun deleteTask(taskId: String) {
        val task = allTasks.value.find { it.id == taskId }
        viewModelScope.launch {
            if (task != null && task.done && !task.hist) {
                repository.updateTask(task.copy(hist = true))
                showToast("Moved to history")
            } else {
                repository.deleteTask(taskId)
                showToast("Task deleted")
            }
        }
    }

    fun restoreTask(taskId: String) {
        val task = allTasks.value.find { it.id == taskId } ?: return
        viewModelScope.launch {
            repository.updateTask(task.copy(hist = false))
            showToast("Task restored")
        }
    }

    fun deleteTaskForever(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
            showToast("Task deleted")
        }
    }

    fun convertTaskToGoal(taskId: String) {
        val task = tasks.value.find { it.id == taskId } ?: return
        val today = DateUtils.todayDs()
        val deadline = if (task.d > today) task.d else ""
        _prefillGoal.value = GoalPrefill(
            name = task.name,
            col = task.col,
            e = deadline
        )
        prefillTaskId = taskId
        setTab("goals")
        showToast("Set your targets, then tap Add goal")
    }

    // Stats actions
    fun setStatsMode(mode: String) {
        _statsMode.value = mode
        _statsAnchor.value = DateUtils.todayDs()
    }

    fun resetStatsToToday() {
        _statsAnchor.value = DateUtils.todayDs()
    }

    fun setStatsScope(scope: String) {
        _statsScope.value = scope
    }

    fun setStatsMetric(metric: String) {
        _statsMetric.value = metric
    }

    fun setHistoryGrouping(g: String) {
        _historyGrouping.value = g
    }

    fun setScoreGrouping(g: String) {
        _scoreGrouping.value = g
    }

    fun navigateStats(direction: Int) {
        val currentAnchor = _statsAnchor.value
        val mode = _statsMode.value
        val newAnchor = when (mode) {
            "year" -> {
                val cal = DateUtils.parseDate(currentAnchor)
                cal.add(java.util.Calendar.YEAR, direction)
                DateUtils.formatDate(cal)
            }
            "month" -> {
                val cal = DateUtils.parseDate(currentAnchor)
                cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
                cal.add(java.util.Calendar.MONTH, direction)
                DateUtils.formatDate(cal)
            }
            "week" -> DateUtils.addDays(currentAnchor, direction * 7)
            "all" -> currentAnchor
            else -> DateUtils.addDays(currentAnchor, direction)
        }
        _statsAnchor.value = newAnchor
    }

    suspend fun exportBackupJson(): String = repository.exportBackupJson()

    suspend fun importBackupJson(json: String): Result<Int> = repository.importBackupJson(json)

    // One page note state & persistence
    private val notesPrefs = application.getSharedPreferences("goal_tracker_notes", android.content.Context.MODE_PRIVATE)

    private val _noteText = MutableStateFlow(notesPrefs.getString("one_page_note_content", "") ?: "")
    val noteText: StateFlow<String> = _noteText.asStateFlow()

    private val _noteTitle = MutableStateFlow(notesPrefs.getString("one_page_note_title", "") ?: "")
    val noteTitle: StateFlow<String> = _noteTitle.asStateFlow()

    fun updateNoteContent(newContent: String) {
        _noteText.value = newContent
        notesPrefs.edit().putString("one_page_note_content", newContent).apply()
    }

    fun updateNoteTitle(newTitle: String) {
        _noteTitle.value = newTitle
        notesPrefs.edit().putString("one_page_note_title", newTitle).apply()
    }

    fun clearNote() {
        _noteText.value = ""
        _noteTitle.value = ""
        notesPrefs.edit().remove("one_page_note_content").remove("one_page_note_title").apply()
        showToast("Note cleared")
    }
}
