package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Task
import com.example.ui.components.ColorPalettePicker
import com.example.ui.components.CustomDatePickerModal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.GoalTrackerViewModel
import com.example.util.DateUtils
import com.example.util.GoalCalculations

@Composable
fun TasksScreen(
    viewModel: GoalTrackerViewModel,
    tasks: List<Task>,
    historyTasks: List<Task>,
    taskMode: String, // "d" or "l"
    taskDeadline: String,
    taskColor: String,
    modifier: Modifier = Modifier
) {
    val today = remember { DateUtils.todayDs() }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var taskInputText by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var isCompletedEarlierExpanded by remember { mutableStateOf(false) }
    var isDeadlinesExpanded by remember { mutableStateOf(true) }
    var isLongTermExpanded by remember { mutableStateOf(true) }
    var showHistory by remember { mutableStateOf(false) }
    val deadlineSortFarthestFirst by viewModel.taskSortFarthest.collectAsState() // saved across app restarts

    // Separate tasks into groups
    val overdueTasks = remember(tasks, today) {
        tasks.filter { it.d.isNotEmpty() && !it.done && it.d < today }.sortedBy { it.d }
    }

    val pastDoneTasks = remember(tasks, today) {
        tasks.filter { it.d.isNotEmpty() && it.done && it.d < today }.sortedByDescending { it.d }
    }

    val futureDates = remember(tasks, today) {
        tasks.filter { it.d.isNotEmpty() && it.d >= today }.map { it.d }.distinct().sorted()
    }

    val sortedFutureDates = remember(futureDates, deadlineSortFarthestFirst) {
        if (deadlineSortFarthestFirst) futureDates.reversed() else futureDates
    }

    val deadlineTasks = remember(tasks) {
        tasks.filter { it.d.isNotEmpty() }
    }
    val deadlineDoneCount = deadlineTasks.count { it.done }
    val deadlineTotalCount = deadlineTasks.size
    val deadlinePct = if (deadlineTotalCount > 0) {
        ((deadlineDoneCount.toFloat() / deadlineTotalCount) * 100).toInt()
    } else 0

    val longTermTasks = remember(tasks) {
        tasks.filter { it.d.isEmpty() }.sortedBy { it.done }
    }
    val longTermDoneCount = longTermTasks.count { it.done }
    val longTermTotalCount = longTermTasks.size
    val longTermPct = if (longTermTotalCount > 0) {
        ((longTermDoneCount.toFloat() / longTermTotalCount) * 100).toInt()
    } else 0

    val todayTasks = remember(tasks, today) {
        tasks.filter { it.d == today }
    }
    val todayDoneCount = todayTasks.count { it.done }

    Column(modifier = modifier.fillMaxWidth()) {
        // Add Task Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(99.dp))
                .background(DarkSurface2)
                .padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = taskInputText,
                onValueChange = { taskInputText = it },
                placeholder = { Text("Add a task…", color = TextMuted, fontSize = 14.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = {
                    if (taskInputText.isNotEmpty()) {
                        viewModel.addTask(taskInputText)
                        taskInputText = ""
                        focusManager.clearFocus()
                        keyboardController?.hide()
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            // Round + button
            val activeColor = GoalCalculations.parseHexColor(taskColor)
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(activeColor)
                    .clickable {
                        if (taskInputText.isNotEmpty()) {
                            viewModel.addTask(taskInputText)
                            taskInputText = ""
                            focusManager.clearFocus()
                            keyboardController?.hide()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "+",
                    color = GoalCalculations.onColor(taskColor),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Options Row: Deadline vs Long-Term Segment, Date Picker, Color Picker
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Mode toggle
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(99.dp))
                    .background(DarkSurface2)
                    .padding(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(if (taskMode == "d") DefaultAccent else Color.Transparent)
                        .clickable { viewModel.setTaskMode("d") }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Deadline",
                        color = if (taskMode == "d") Color(0xFF06100B) else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(if (taskMode == "l") DefaultAccent else Color.Transparent)
                        .clickable { viewModel.setTaskMode("l") }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Long-term",
                        color = if (taskMode == "l") Color(0xFF06100B) else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Deadline date picker trigger (only in Deadline mode)
            if (taskMode == "d") {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(DarkSurface2)
                        .clickable { showDatePicker = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "${DateUtils.formatDM(taskDeadline)} ▾",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Color circles
            ColorPalettePicker(
                selectedColor = taskColor,
                onColorSelected = { viewModel.setTaskColor(it) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // History menu button
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(99.dp))
                    .background(DarkSurface2)
                    .clickable { showHistory = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "History (${historyTasks.size})",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        if (showHistory) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showHistory = false },
                containerColor = DarkCard,
                title = { Text("Task history", color = TextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    if (historyTasks.isEmpty()) {
                        Text("Nothing here yet. Done tasks you remove with × are kept here.", color = TextMuted, fontSize = 13.sp)
                    } else {
                        Column(
                            modifier = Modifier
                                .heightIn(max = 380.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            historyTasks.sortedByDescending { it.d }.forEach { t ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = t.name,
                                            color = TextMuted,
                                            fontSize = 14.sp,
                                            textDecoration = TextDecoration.LineThrough
                                        )
                                        if (t.d.isNotEmpty()) {
                                            Text(
                                                text = "Due ${DateUtils.formatDM(t.d)}",
                                                color = TextMuted,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    androidx.compose.material3.TextButton(onClick = { viewModel.restoreTask(t.id) }) {
                                        Text("Restore", fontSize = 12.sp)
                                    }
                                    androidx.compose.material3.TextButton(onClick = { viewModel.deleteTaskForever(t.id) }) {
                                        Text("Delete", color = DangerRed, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = { showHistory = false }) { Text("Close") }
                }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SECTION 1: BY DEADLINE (Collapsible with tiny % completion and sort toggle)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { isDeadlinesExpanded = !isDeadlinesExpanded }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (isDeadlinesExpanded) "▾" else "▸",
                    color = TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "BY DEADLINE",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                if (deadlineTotalCount > 0) {
                    Text(
                        text = "($deadlineDoneCount/$deadlineTotalCount)",
                        color = TextMuted.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Sort toggle: Farthest at top ⇅ vs Earliest at top ⇅
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(DarkSurface2)
                        .clickable { viewModel.toggleTaskSort() }
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (deadlineSortFarthestFirst) "Farthest at top ⇅" else "Earliest at top ⇅",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Tiny % completion
                if (deadlineTotalCount > 0) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(DarkSurface2)
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$deadlinePct%",
                            color = if (deadlinePct >= 100) DefaultAccent else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        AnimatedVisibility(visible = isDeadlinesExpanded) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Today's completion indicator
                if (todayTasks.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Today $todayDoneCount/${todayTasks.size}",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(DarkSurface2)
                        ) {
                            val ratio = (todayDoneCount.toFloat() / todayTasks.size).coerceIn(0f, 1f)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(ratio)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(DefaultAccent)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Overdue tasks if earliest at top
                if (!deadlineSortFarthestFirst && overdueTasks.isNotEmpty()) {
                    TaskGroupHeader(
                        symbol = "!",
                        title = "Overdue",
                        subtitle = "needs attention",
                        count = overdueTasks.count { !it.done },
                        isOverdue = true
                    )
                    overdueTasks.forEach { task ->
                        TaskRowItem(
                            task = task,
                            showDate = true,
                            onToggle = { viewModel.toggleTask(task.id) },
                            onDelete = { viewModel.deleteTask(task.id) },
                            onToGoal = { viewModel.convertTaskToGoal(task.id) }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Future dates tasks according to sort order (farthest first by default!)
                sortedFutureDates.forEach { d ->
                    val dateTasks = tasks.filter { it.d == d }.sortedBy { it.done }
                    val cal = DateUtils.parseDate(d)
                    val dayOfMonth = cal.get(java.util.Calendar.DAY_OF_MONTH).toString()
                    val dayTitle = when (d) {
                        today -> "Today"
                        DateUtils.addDays(today, 1) -> "Tomorrow"
                        else -> java.text.SimpleDateFormat("EEEE", java.util.Locale.ENGLISH).format(cal.time)
                    }
                    val subtitle = java.text.SimpleDateFormat("EEE, MMM", java.util.Locale.ENGLISH).format(cal.time)

                    TaskGroupHeader(
                        symbol = dayOfMonth,
                        title = dayTitle,
                        subtitle = subtitle,
                        count = dateTasks.count { !it.done },
                        isOverdue = false
                    )

                    dateTasks.forEach { task ->
                        TaskRowItem(
                            task = task,
                            showDate = false,
                            onToggle = { viewModel.toggleTask(task.id) },
                            onDelete = { viewModel.deleteTask(task.id) },
                            onToGoal = { viewModel.convertTaskToGoal(task.id) }
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Overdue tasks if farthest at top
                if (deadlineSortFarthestFirst && overdueTasks.isNotEmpty()) {
                    TaskGroupHeader(
                        symbol = "!",
                        title = "Overdue",
                        subtitle = "needs attention",
                        count = overdueTasks.count { !it.done },
                        isOverdue = true
                    )
                    overdueTasks.forEach { task ->
                        TaskRowItem(
                            task = task,
                            showDate = true,
                            onToggle = { viewModel.toggleTask(task.id) },
                            onDelete = { viewModel.deleteTask(task.id) },
                            onToGoal = { viewModel.convertTaskToGoal(task.id) }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                if (tasks.none { it.d.isNotEmpty() }) {
                    Text(
                        text = "✨ No deadlines yet. Add one above.",
                        color = TextMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                }

                // Completed Earlier Collapsible
                if (pastDoneTasks.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isCompletedEarlierExpanded = !isCompletedEarlierExpanded },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Completed earlier (${pastDoneTasks.size})",
                            color = TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isCompletedEarlierExpanded) "−" else "+",
                            color = TextMuted,
                            fontSize = 16.sp
                        )
                    }

                    AnimatedVisibility(visible = isCompletedEarlierExpanded) {
                        Column(modifier = Modifier.padding(top = 6.dp)) {
                            pastDoneTasks.forEach { task ->
                                TaskRowItem(
                                    task = task,
                                    showDate = true,
                                    onToggle = { viewModel.toggleTask(task.id) },
                                    onDelete = { viewModel.deleteTask(task.id) },
                                    onToGoal = { viewModel.convertTaskToGoal(task.id) }
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION 2: LONG-TERM · NO DEADLINE (Collapsible with long term tasks bar and tiny % completion)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { isLongTermExpanded = !isLongTermExpanded }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = if (isLongTermExpanded) "▾" else "▸",
                    color = TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "LONG-TERM · NO DEADLINE",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
                if (longTermTotalCount > 0) {
                    Text(
                        text = "($longTermDoneCount/$longTermTotalCount)",
                        color = TextMuted.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        AnimatedVisibility(visible = isLongTermExpanded) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Long term tasks bar (progress bar without percentage)
                if (longTermTasks.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Long-term $longTermDoneCount/$longTermTotalCount",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(9.dp))
                                .background(DarkSurface2)
                        ) {
                            val ratio = if (longTermTotalCount > 0) {
                                (longTermDoneCount.toFloat() / longTermTotalCount).coerceIn(0f, 1f)
                            } else 0f
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(ratio)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(DefaultAccent)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                if (longTermTasks.isEmpty()) {
                    Text(
                        text = "🌱 Nothing long-term yet. Choose Long-term when adding.",
                        color = TextMuted,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    longTermTasks.forEach { task ->
                        TaskRowItem(
                            task = task,
                            showDate = false,
                            onToggle = { viewModel.toggleTask(task.id) },
                            onDelete = { viewModel.deleteTask(task.id) },
                            onToGoal = { viewModel.convertTaskToGoal(task.id) }
                        )
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        CustomDatePickerModal(
            initialDate = taskDeadline,
            onDismissRequest = { showDatePicker = false },
            onDateSelected = { viewModel.setTaskDeadline(it) }
        )
    }
}

@Composable
fun TaskGroupHeader(
    symbol: String,
    title: String,
    subtitle: String,
    count: Int,
    isOverdue: Boolean
) {
    val highlightColor = if (isOverdue) DangerRed else DefaultAccent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = symbol,
            color = highlightColor,
            fontSize = 24.sp,
            fontWeight = FontWeight.ExtraBold,
            lineHeight = 24.sp
        )

        Column {
            Text(
                text = title,
                color = if (isOverdue) DangerRed else TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        // Horizontal divider line
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(DarkBorder)
        )

        // Count pill
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(DarkSurface2)
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = count.toString(),
                color = TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun TaskRowItem(
    task: Task,
    showDate: Boolean,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onToGoal: () -> Unit
) {
    val taskColor = GoalCalculations.parseHexColor(task.col)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Circular check button
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .border(1.6.dp, taskColor, CircleShape)
                .background(if (task.done) taskColor else Color.Transparent)
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (task.done) {
                Text(
                    text = "✓",
                    color = GoalCalculations.onColor(task.col),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Title and optional date
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = task.name,
                color = if (task.done) TextMuted else TextPrimary,
                fontSize = 14.sp,
                textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None
            )
            if (showDate && task.d.isNotEmpty()) {
                Text(
                    text = DateUtils.formatDM(task.d),
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Turn into goal button (only for uncompleted long-term tasks or task without date)
        if (!task.done && task.d.isEmpty()) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurface2)
                    .clickable { onToGoal() }
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "↗ Goal",
                    color = taskColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Delete button ×
        IconButton(
            onClick = onDelete,
            modifier = Modifier.size(28.dp)
        ) {
            Text("×", color = TextMuted, fontSize = 18.sp)
        }
    }
}
