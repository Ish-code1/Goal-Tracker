package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.util.GoalCalculations

@Composable
fun PillTabs(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    activeColor: Color = DefaultAccent,
    modifier: Modifier = Modifier
) {
    val tabs = listOf(
        "today" to "Today",
        "goals" to "Goals",
        "stats" to "Stats",
        "tasks" to "Tasks",
        "notes" to "Notes"
    )

    val selectedIndex = tabs.indexOfFirst { it.first == selectedTab }.coerceAtLeast(0)

    val targetOffset by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = 0.8f,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "tabSlider"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(DarkCard.copy(alpha = 0.84f))
            .border(1.dp, DarkBorder, RoundedCornerShape(99.dp))
            .padding(4.dp)
    ) {
        val tabWidth = (maxWidth) / tabs.size

        // Sliding indicator background pill
        Box(
            modifier = Modifier
                .offset(x = tabWidth * targetOffset)
                .width(tabWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(99.dp))
                .background(activeColor)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {
            tabs.forEachIndexed { index, (key, label) ->
                val isSelected = index == selectedIndex
                val textColor = if (isSelected) {
                    GoalCalculations.onColor(String.format("#%06X", (activeColor.value.toLong() and 0xFFFFFFL)))
                } else {
                    TextMuted
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(99.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            onTabSelected(key)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = textColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
