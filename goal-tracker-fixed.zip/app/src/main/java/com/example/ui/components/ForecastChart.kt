package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.TextMuted
import com.example.util.DateUtils

data class ForecastChartData(
    val yMax: Double,
    val target: Double,
    val totalDays: Int, // xm in html
    val deadlineDayIndex: Int, // tot-1
    val actualPoints: List<Pair<Int, Double>>, // dayIndex, cumulativeValue
    val projectionPoints: List<Pair<Int, Double>>, // dayIndex, projectedValue
    val finishPoint: Pair<Int, Double>?, // if projected to hit target
    val finishDateLabel: String,
    val startDateLabel: String,
    val endDateLabel: String
)

@Composable
fun ForecastChart(
    data: ForecastChartData,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
        ) {
            // Y-axis labels
            Column(
                modifier = Modifier
                    .width(36.dp)
                    .height(120.dp),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End
            ) {
                Text(DateUtils.round1(data.yMax).toString(), color = TextMuted, fontSize = 9.sp)
                Text(DateUtils.round1(data.yMax / 2).toString(), color = TextMuted, fontSize = 9.sp)
                Text("0", color = TextMuted, fontSize = 9.sp)
            }

            // Canvas area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(120.dp)
                    .padding(start = 6.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val w = size.width
                    val h = size.height

                    // Left & Bottom borders
                    drawLine(DarkBorder, Offset(0f, 0f), Offset(0f, h), strokeWidth = 1.dp.toPx())
                    drawLine(DarkBorder, Offset(0f, h), Offset(w, h), strokeWidth = 1.dp.toPx())

                    val maxVal = if (data.yMax > 0) data.yMax else 1.0
                    val totalDays = if (data.totalDays > 1) data.totalDays.toFloat() else 1f

                    fun xCoord(dayIndex: Int): Float = (dayIndex.toFloat() / (totalDays - 1).coerceAtLeast(1f)) * w
                    fun yCoord(value: Double): Float = h * (1f - (value / maxVal).toFloat().coerceIn(0f, 1f))

                    // Target horizontal dashed line
                    if (data.target > 0) {
                        val targetY = yCoord(data.target)
                        drawLine(
                            color = TextMuted.copy(alpha = 0.6f),
                            start = Offset(0f, targetY),
                            end = Offset(w, targetY),
                            strokeWidth = 1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                        )
                    }

                    // Deadline vertical line
                    if (data.deadlineDayIndex > 0) {
                        val deadlineX = xCoord(data.deadlineDayIndex)
                        drawLine(
                            color = TextMuted.copy(alpha = 0.5f),
                            start = Offset(deadlineX, 0f),
                            end = Offset(deadlineX, h),
                            strokeWidth = 2.dp.toPx()
                        )
                    }

                    // Solid historical line
                    if (data.actualPoints.isNotEmpty()) {
                        val actualPath = Path()
                        data.actualPoints.forEachIndexed { idx, (dayIdx, cumVal) ->
                            val ptX = xCoord(dayIdx)
                            val ptY = yCoord(cumVal)
                            if (idx == 0) actualPath.moveTo(ptX, ptY) else actualPath.lineTo(ptX, ptY)
                        }
                        drawPath(actualPath, lineColor, style = Stroke(width = 3.dp.toPx()))
                    }

                    // Dashed projection line
                    if (data.projectionPoints.isNotEmpty()) {
                        val projPath = Path()
                        data.projectionPoints.forEachIndexed { idx, (dayIdx, cumVal) ->
                            val ptX = xCoord(dayIdx)
                            val ptY = yCoord(cumVal)
                            if (idx == 0) projPath.moveTo(ptX, ptY) else projPath.lineTo(ptX, ptY)
                        }
                        drawPath(
                            projPath,
                            lineColor,
                            style = Stroke(
                                width = 2.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                            )
                        )
                    }

                    // Finish dot
                    data.finishPoint?.let { (finishDay, finishVal) ->
                        val fx = xCoord(finishDay)
                        val fy = yCoord(finishVal)
                        drawCircle(lineColor, radius = 5.dp.toPx(), center = Offset(fx, fy))
                    }
                }
            }
        }

        // Bottom labels: start date and end date
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 42.dp, top = 4.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
        ) {
            Text(data.startDateLabel, color = TextMuted, fontSize = 10.sp)
            Text(data.endDateLabel, color = TextMuted, fontSize = 10.sp)
        }
    }
}
