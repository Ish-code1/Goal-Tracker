package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.util.DateUtils
import kotlin.math.max

data class BucketItem(
    val label: String,
    val slices: List<Pair<Double, Color>>, // value, color
    val total: Double
)

@Composable
fun HistoryBarChart(
    buckets: List<BucketItem>,
    modifier: Modifier = Modifier
) {
    val maxTotal = max(0.001, buckets.maxOfOrNull { it.total } ?: 0.0)

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            // Background horizontal grid lines at 25, 50, 75, 100%
            Column(
                modifier = Modifier.matchParentSize(),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween
            ) {
                repeat(4) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(DarkBorder)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )
            }

            // Stacked bars row
            Row(
                modifier = Modifier
                    .matchParentSize()
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)
            ) {
                buckets.forEach { bucket ->
                    val heightRatio = (bucket.total / maxTotal).toFloat().coerceIn(0f, 1f)

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (bucket.total > 0) {
                            Text(
                                text = DateUtils.round1(bucket.total).toString(),
                                color = DefaultAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }

                        // Stacked bar container
                        val barHeight = (105.dp * heightRatio)
                        if (barHeight > 0.dp && bucket.total > 0) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(barHeight)
                                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            ) {
                                bucket.slices.forEach { (sliceVal, color) ->
                                    if (sliceVal > 0) {
                                        val sliceWeight = (sliceVal / bucket.total).toFloat().coerceAtLeast(0.001f)
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(sliceWeight)
                                                .background(color)
                                        )
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.height(2.dp))
                        }
                    }
                }
            }
        }

        // X-axis labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
        ) {
            buckets.forEach { bucket ->
                Text(
                    text = bucket.label,
                    modifier = Modifier.weight(1f),
                    color = TextMuted,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}
