package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted

@Composable
fun ScoreLineChart(
    points: List<Double>, // 0.0 to 1.0 (usually 10 points)
    labels: List<String>,
    lineColor: Color = DefaultAccent,
    modifier: Modifier = Modifier
) {
    val yLevels = listOf(1.0, 0.8, 0.6, 0.4, 0.2)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        ) {
            // Y-axis percentage labels
            Column(
                modifier = Modifier
                    .width(36.dp)
                    .height(130.dp),
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.End
            ) {
                yLevels.forEach { lvl ->
                    Text(
                        text = "${(lvl * 100).toInt()}%",
                        color = TextMuted,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }

            // Chart Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(130.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxWidth().height(130.dp)) {
                    val w = size.width
                    val h = size.height
                    val n = points.size

                    // Grid lines at 20, 40, 60, 80, 100%
                    yLevels.forEach { lvl ->
                        val y = h * (1f - lvl.toFloat())
                        drawLine(
                            color = DarkBorder,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    if (n > 1) {
                        val path = Path()
                        val dotOffsets = mutableListOf<Offset>()

                        points.forEachIndexed { i, value ->
                            val x = ((i + 0.5f) / n) * w
                            val y = h * (1f - value.toFloat().coerceIn(0f, 1f))
                            val offset = Offset(x, y)
                            dotOffsets.add(offset)
                            if (i == 0) {
                                path.moveTo(x, y)
                            } else {
                                path.lineTo(x, y)
                            }
                        }

                        // Draw continuous polyline
                        drawPath(
                            path = path,
                            color = lineColor,
                            style = Stroke(
                                width = 2.5f.dp.toPx(),
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )

                        // Draw point dots
                        dotOffsets.forEach { offset ->
                            drawCircle(
                                color = lineColor,
                                radius = 4.5f.dp.toPx(),
                                center = offset
                            )
                        }
                    }
                }
            }
        }

        // X-axis labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 36.dp, top = 6.dp)
        ) {
            labels.forEach { label ->
                Text(
                    text = label,
                    modifier = Modifier.weight(1f),
                    color = TextMuted,
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}
