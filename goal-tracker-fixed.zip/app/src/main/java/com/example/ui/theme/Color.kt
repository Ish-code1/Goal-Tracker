package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode(val id: String, val displayName: String, val icon: String) {
    DARK("dark", "Dark", "🌙"),
    LIGHT("light", "Light", "☀️"),
    MIDNIGHT("midnight", "Midnight", "🌌"),
    FOREST("forest", "Forest", "🌲"),
    PINK("pink", "Pink", "🌸"),
    PURPLE("purple", "Purple", "💜")
}

data class AppColors(
    val bg: Color,
    val card: Color,
    val surface2: Color,
    val border: Color,
    val textPrimary: Color,
    val textMuted: Color,
    val accent: Color,
    val danger: Color,
    val success: Color,
    val warning: Color,
    val isDark: Boolean
)

val DarkThemeColors = AppColors(
    bg = Color(0xFF0B0C0E),
    card = Color(0xFF141518),
    surface2 = Color(0xFF1D1F23),
    border = Color(0xFF1F2125),
    textPrimary = Color(0xFFECEEF1),
    textMuted = Color(0xFF868B95),
    accent = Color(0xFF60A5FA),
    danger = Color(0xFFF26D6D),
    success = Color(0xFF2F9E6B),
    warning = Color(0xFFE0883A),
    isDark = true
)

val LightThemeColors = AppColors(
    bg = Color(0xFFF6F8FA),
    card = Color(0xFFFFFFFF),
    surface2 = Color(0xFFEAEFF5),
    border = Color(0xFFD8DEE4),
    textPrimary = Color(0xFF1F2328),
    textMuted = Color(0xFF656D76),
    accent = Color(0xFF2563EB),
    danger = Color(0xFFDC2626),
    success = Color(0xFF16A34A),
    warning = Color(0xFFD97706),
    isDark = false
)

val MidnightThemeColors = AppColors(
    bg = Color(0xFF070B19),
    card = Color(0xFF0F172A),
    surface2 = Color(0xFF1E293B),
    border = Color(0xFF1E293B),
    textPrimary = Color(0xFFF1F5F9),
    textMuted = Color(0xFF94A3B8),
    accent = Color(0xFF818CF8),
    danger = Color(0xFFF87171),
    success = Color(0xFF34D399),
    warning = Color(0xFFFBBF24),
    isDark = true
)

val ForestThemeColors = AppColors(
    bg = Color(0xFF07130E),
    card = Color(0xFF0F1F17),
    surface2 = Color(0xFF182D23),
    border = Color(0xFF1D3B2E),
    textPrimary = Color(0xFFECFDF5),
    textMuted = Color(0xFF86A795),
    accent = Color(0xFF10B981),
    danger = Color(0xFFF87171),
    success = Color(0xFF34D399),
    warning = Color(0xFFFBBF24),
    isDark = true
)

val PinkThemeColors = AppColors(
    bg = Color(0xFF180A12), // Deep velvety blush dark
    card = Color(0xFF281320),
    surface2 = Color(0xFF391A2E),
    border = Color(0xFF451E38),
    textPrimary = Color(0xFFFDF2F8),
    textMuted = Color(0xFFD4A5B8),
    accent = Color(0xFFF472B6), // Bright Rose / Pink
    danger = Color(0xFFFB7185),
    success = Color(0xFF34D399),
    warning = Color(0xFFFBBF24),
    isDark = true
)

val PurpleThemeColors = AppColors(
    bg = Color(0xFF11071F), // Deep royal violet night
    card = Color(0xFF1F1037),
    surface2 = Color(0xFF2E194F),
    border = Color(0xFF3B1E66),
    textPrimary = Color(0xFFF5F3FF),
    textMuted = Color(0xFFA78BFA),
    accent = Color(0xFFC084FC), // Electric Purple / Lavender
    danger = Color(0xFFF87171),
    success = Color(0xFF34D399),
    warning = Color(0xFFFBBF24),
    isDark = true
)

// Active colors held in a global state that works seamlessly in and out of @Composable (including DrawScope, pure functions, Canvas)
private var currentColorsInternal: AppColors = DarkThemeColors

fun updateCurrentAppColors(colors: AppColors) {
    currentColorsInternal = colors
}

val LocalAppColors = staticCompositionLocalOf { DarkThemeColors }

// Dynamic property accessors that return the current active theme color everywhere
val DarkBg: Color
    get() = currentColorsInternal.bg

val DarkCard: Color
    get() = currentColorsInternal.card

val DarkSurface2: Color
    get() = currentColorsInternal.surface2

val DarkBorder: Color
    get() = currentColorsInternal.border

val TextPrimary: Color
    get() = currentColorsInternal.textPrimary

val TextMuted: Color
    get() = currentColorsInternal.textMuted

val DefaultAccent: Color
    get() = currentColorsInternal.accent

val DangerRed: Color
    get() = currentColorsInternal.danger

val SuccessGreen: Color
    get() = currentColorsInternal.success

val WarningOrange: Color
    get() = currentColorsInternal.warning
