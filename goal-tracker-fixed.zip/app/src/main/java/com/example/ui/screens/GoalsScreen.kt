package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.ui.components.ColorPalettePicker
import com.example.ui.components.CustomDatePickerModal
import com.example.ui.components.CustomTimePickerModal
import androidx.compose.runtime.collectAsState
import com.example.ui.theme.AppThemeMode
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.GoalPrefill
import com.example.ui.viewmodel.GoalTrackerViewModel
import com.example.util.DateUtils
import com.example.util.GoalCalculations
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max

@Composable
fun GoalsScreen(
    viewModel: GoalTrackerViewModel,
    goals: List<Goal>,
    logs: List<LogEntry>,
    prefill: GoalPrefill?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val coroutineScope = rememberCoroutineScope()
    val today = remember { DateUtils.todayDs() }

    // 6 months default deadline
    val defaultDeadline = remember {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.MONTH, 6)
        DateUtils.formatDate(cal)
    }

    // New Goal Form State
    var isNewGoalExpanded by remember { mutableStateOf(goals.isEmpty() || prefill != null) }
    var newGoalName by remember { mutableStateOf("") }
    var newHoursDaily by remember { mutableStateOf("") }
    var newHoursTotal by remember { mutableStateOf("") }
    var newUnitsName by remember { mutableStateOf("") }
    var newUnitsDaily by remember { mutableStateOf("") }
    var newUnitsTotal by remember { mutableStateOf("") }
    var newGoalColor by remember { mutableStateOf(GoalCalculations.PALETTE[0]) }
    var newGoalDeadline by remember { mutableStateOf(defaultDeadline) }
    var newSlotStart by remember { mutableStateOf("") }
    var newSlotEnd by remember { mutableStateOf("") }

    // Modal pickers for new goal
    var showNewDeadlinePicker by remember { mutableStateOf(false) }
    var showNewSlotStartPicker by remember { mutableStateOf(false) }
    var showNewSlotEndPicker by remember { mutableStateOf(false) }

    // File Pickers for Export & Import
    val saveFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val json = viewModel.exportBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(json.toByteArray(Charsets.UTF_8))
                    }
                    viewModel.showToast("Backup saved to file successfully")
                } catch (e: Exception) {
                    viewModel.showToast("Failed to save backup: ${e.message}")
                }
            }
        }
    }

    val openFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val content = context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        inputStream.bufferedReader(Charsets.UTF_8).readText()
                    } ?: ""
                    if (content.isNotEmpty()) {
                        val res = viewModel.importBackupJson(content)
                        if (res.isSuccess) {
                            viewModel.showToast("Imported ${res.getOrNull()} items successfully")
                        } else {
                            viewModel.showToast("Could not read backup file")
                        }
                    }
                } catch (e: Exception) {
                    viewModel.showToast("Error reading file: ${e.message}")
                }
            }
        }
    }

    // Handle prefill if converting a task to goal
    LaunchedEffect(prefill) {
        if (prefill != null) {
            newGoalName = prefill.name
            newGoalColor = prefill.col
            if (prefill.e.isNotEmpty()) {
                newGoalDeadline = prefill.e
            }
            isNewGoalExpanded = true
        }
    }

    // Backup state
    var isBackupExpanded by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }

    Column(modifier = modifier.fillMaxWidth()) {
        // "New goal" Expandable Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isNewGoalExpanded = !isNewGoalExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "New goal",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isNewGoalExpanded) "−" else "+",
                        color = TextMuted,
                        fontSize = 20.sp
                    )
                }

                AnimatedVisibility(visible = isNewGoalExpanded) {
                    Column(modifier = Modifier.padding(top = 14.dp)) {
                        // Goal Name
                        OutlinedTextField(
                            value = newGoalName,
                            onValueChange = { newGoalName = it },
                            placeholder = { Text("Goal name (e.g. DSA sheet)", color = TextMuted, fontSize = 14.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = DefaultAccent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Target Hours (Daily & Total)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = newHoursDaily,
                                onValueChange = { newHoursDaily = it },
                                label = { Text("Hours per day", color = TextMuted, fontSize = 11.sp) },
                                placeholder = { Text("e.g. 2", color = TextMuted, fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface2,
                                    unfocusedContainerColor = DarkSurface2,
                                    focusedBorderColor = DefaultAccent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )

                            OutlinedTextField(
                                value = newHoursTotal,
                                onValueChange = { newHoursTotal = it },
                                label = { Text("Total hours", color = TextMuted, fontSize = 11.sp) },
                                placeholder = { Text("e.g. 300", color = TextMuted, fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface2,
                                    unfocusedContainerColor = DarkSurface2,
                                    focusedBorderColor = DefaultAccent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // What you count (units)
                        OutlinedTextField(
                            value = newUnitsName,
                            onValueChange = { newUnitsName = it },
                            label = { Text("What you count", color = TextMuted, fontSize = 11.sp) },
                            placeholder = { Text("videos, questions…", color = TextMuted, fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = DefaultAccent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Target Count (Daily & Total)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = newUnitsDaily,
                                onValueChange = { newUnitsDaily = it },
                                label = { Text("Count per day", color = TextMuted, fontSize = 11.sp) },
                                placeholder = { Text("e.g. 5", color = TextMuted, fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface2,
                                    unfocusedContainerColor = DarkSurface2,
                                    focusedBorderColor = DefaultAccent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )

                            OutlinedTextField(
                                value = newUnitsTotal,
                                onValueChange = { newUnitsTotal = it },
                                label = { Text("Total count", color = TextMuted, fontSize = 11.sp) },
                                placeholder = { Text("e.g. 400", color = TextMuted, fontSize = 13.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface2,
                                    unfocusedContainerColor = DarkSurface2,
                                    focusedBorderColor = DefaultAccent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        // Consistency validation feedback check (chkNew)
                        val daysSpan = max(1, DateUtils.daysDiff(today, newGoalDeadline) + 1)
                        val hDaily = newHoursDaily.toDoubleOrNull() ?: 0.0
                        val hTot = newHoursTotal.toDoubleOrNull() ?: 0.0
                        val uDaily = newUnitsDaily.toDoubleOrNull() ?: 0.0
                        val uTot = newUnitsTotal.toDoubleOrNull() ?: 0.0
                        val uName = newUnitsName.trim().ifEmpty { "units" }

                        val hoursWarning = checkConsistency("Hours", hDaily, hTot, daysSpan, "h")
                        val unitsWarning = checkConsistency(uName, uDaily, uTot, daysSpan, uName)

                        if (hoursWarning != null || unitsWarning != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            hoursWarning?.let { (msg, col) ->
                                Text(msg, color = col, fontSize = 12.sp)
                            }
                            unitsWarning?.let { (msg, col) ->
                                Text(msg, color = col, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tip: fill per-day or total, not both. The other is worked out from the days between Start and Deadline.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Color selection
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Colour", color = TextMuted, fontSize = 13.sp)
                            ColorPalettePicker(
                                selectedColor = newGoalColor,
                                onColorSelected = { newGoalColor = it }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Daily slot time window
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkSurface2)
                                    .clickable { showNewSlotStartPicker = true }
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text("Daily slot from", color = TextMuted, fontSize = 11.sp)
                                    Text(
                                        text = newSlotStart.ifEmpty { "--:--" },
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(DarkSurface2)
                                    .clickable { showNewSlotEndPicker = true }
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text("until", color = TextMuted, fontSize = 11.sp)
                                    Text(
                                        text = newSlotEnd.ifEmpty { "--:--" },
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Optional: the time window you plan to complete this goal each day.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Deadline & Add Goal Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("Deadline", color = TextMuted, fontSize = 13.sp)
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurface2)
                                        .clickable { showNewDeadlinePicker = true }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = "${DateUtils.formatDM(newGoalDeadline)} ▾",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    viewModel.addGoal(
                                        name = newGoalName,
                                        deadline = newGoalDeadline,
                                        startSlot = newSlotStart,
                                        endSlot = newSlotEnd,
                                        hoursPerDay = newHoursDaily.toDoubleOrNull() ?: 0.0,
                                        totalHours = newHoursTotal.toDoubleOrNull() ?: 0.0,
                                        countPerDay = newUnitsDaily.toDoubleOrNull() ?: 0.0,
                                        totalCount = newUnitsTotal.toDoubleOrNull() ?: 0.0,
                                        units = newUnitsName,
                                        colorHex = newGoalColor
                                    )
                                    // Reset inputs and advance color for next goal
                                    newGoalName = ""
                                    newHoursDaily = ""
                                    newHoursTotal = ""
                                    newUnitsName = ""
                                    newUnitsDaily = ""
                                    newUnitsTotal = ""
                                    newSlotStart = ""
                                    newSlotEnd = ""
                                    val palette = GoalCalculations.PALETTE
                                    val curIdx = palette.indexOfFirst { it.equals(newGoalColor, ignoreCase = true) }
                                    newGoalColor = palette[if (curIdx >= 0) (curIdx + 1) % palette.size else 0]
                                    isNewGoalExpanded = false
                                    focusManager.clearFocus()
                                    keyboardController?.hide()
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GoalCalculations.parseHexColor(newGoalColor),
                                    contentColor = GoalCalculations.onColor(newGoalColor)
                                )
                            ) {
                                Text("Add goal", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Existing Goals List
        if (goals.isEmpty()) {
            Text(
                text = "No goals yet.",
                color = TextMuted,
                fontSize = 14.sp,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        } else {
            goals.sortedBy { it.dn != null }.forEach { goal ->
                GoalItemCard(
                    goal = goal,
                    logs = logs,
                    today = today,
                    viewModel = viewModel
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Backup & Restore Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isBackupExpanded = !isBackupExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Backup",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (isBackupExpanded) "−" else "+",
                        color = TextMuted,
                        fontSize = 18.sp
                    )
                }

                AnimatedVisibility(visible = isBackupExpanded) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        Text(
                            text = "Your data is saved on this device. Export a copy to keep it safe or move it to another device.",
                            color = TextMuted,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // File actions (Recommended for full backups)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    saveFileLauncher.launch("GoalTracker_backup_${today}.json")
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DefaultAccent,
                                    contentColor = Color(0xFF06100B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Save File (.json)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    openFileLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DarkSurface2,
                                    contentColor = TextPrimary
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Load File (.json)", fontSize = 13.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Text / Share actions
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        val json = viewModel.exportBackupJson()
                                        backupJsonText = json
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("GoalTrackerBackup", json))
                                        viewModel.showToast("Backup copied to clipboard")
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface2)
                            ) {
                                Text("Copy Text", color = TextPrimary)
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        val json = viewModel.exportBackupJson()
                                        backupJsonText = json
                                        val sendIntent = Intent().apply {
                                            action = Intent.ACTION_SEND
                                            putExtra(Intent.EXTRA_TEXT, json)
                                            putExtra(Intent.EXTRA_TITLE, "GoalTracker_backup_${today}.json")
                                            type = "text/plain"
                                        }
                                        val shareIntent = Intent.createChooser(sendIntent, "Share Backup JSON")
                                        context.startActivity(shareIntent)
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface2)
                            ) {
                                Text("Share", color = TextPrimary)
                            }

                            Button(
                                onClick = {
                                    if (backupJsonText.trim().startsWith("{")) {
                                        coroutineScope.launch {
                                            val res = viewModel.importBackupJson(backupJsonText)
                                            if (res.isSuccess) {
                                                viewModel.showToast("Imported ${res.getOrNull()} items")
                                            } else {
                                                viewModel.showToast("Could not read that backup")
                                            }
                                        }
                                    } else {
                                        viewModel.showToast("Paste your backup JSON below, then tap Import")
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface2)
                            ) {
                                Text("Import Text", color = TextPrimary)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = backupJsonText,
                            onValueChange = { backupJsonText = it },
                            placeholder = { Text("Paste JSON backup here...", color = TextMuted, fontSize = 11.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = DefaultAccent,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }

        }

        // Appearance & Themes Card
        val currentTheme by viewModel.themeMode.collectAsState()
        var isThemeExpanded by remember { mutableStateOf(false) }

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .border(1.dp, DarkBorder, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isThemeExpanded = !isThemeExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎨", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Appearance & Theme (${currentTheme.displayName})",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (isThemeExpanded) "−" else "+",
                        color = TextMuted,
                        fontSize = 18.sp
                    )
                }

                AnimatedVisibility(visible = isThemeExpanded) {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        Text(
                            text = "Choose your preferred color theme:",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppThemeMode.values().toList().chunked(3).forEach { rowModes ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowModes.forEach { mode ->
                                        val isSelected = mode == currentTheme
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(if (isSelected) DefaultAccent.copy(alpha = 0.2f) else DarkSurface2)
                                                .border(
                                                    width = if (isSelected) 1.5.dp else 1.dp,
                                                    color = if (isSelected) DefaultAccent else DarkBorder,
                                                    shape = RoundedCornerShape(12.dp)
                                                )
                                                .clickable { viewModel.setThemeMode(mode) }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(mode.icon, fontSize = 18.sp)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = mode.displayName,
                                                    color = if (isSelected) DefaultAccent else TextPrimary,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewDeadlinePicker) {
        CustomDatePickerModal(
            initialDate = newGoalDeadline,
            onDismissRequest = { showNewDeadlinePicker = false },
            onDateSelected = { newGoalDeadline = it }
        )
    }

    if (showNewSlotStartPicker) {
        CustomTimePickerModal(
            initialTime = newSlotStart,
            onDismissRequest = { showNewSlotStartPicker = false },
            onTimeSelected = { newSlotStart = it }
        )
    }

    if (showNewSlotEndPicker) {
        CustomTimePickerModal(
            initialTime = newSlotEnd,
            onDismissRequest = { showNewSlotEndPicker = false },
            onTimeSelected = { newSlotEnd = it }
        )
    }
}

fun checkConsistency(name: String, daily: Double, total: Double, days: Int, units: String): Pair<String, Color>? {
    if (daily <= 0 || total <= 0) return null
    val reach = daily * days
    if (reach < total * 0.97) {
        val needed = DateUtils.round1(total / days)
        return Pair(
            "$name: ${DateUtils.round1(daily)}/day x $days days = only ${DateUtils.round1(reach)} $units, short of your total ${DateUtils.round1(total)}. You need $needed/day to make it.",
            DangerRed
        )
    }
    if (reach > total * 1.03) {
        val daysNeeded = ceil(total / daily).toInt()
        val daysBefore = max(0, days - daysNeeded)
        val lowerTo = DateUtils.round1(total / days)
        return Pair(
            "$name: at ${DateUtils.round1(daily)}/day you finish ${DateUtils.round1(total)} $units in $daysNeeded days, $daysBefore days before deadline. Lower it to $lowerTo/day or raise the total.",
            WarningOrange
        )
    }
    return Pair("$name: per-day and total match.", SuccessGreen)
}

@Composable
fun GoalItemCard(
    goal: Goal,
    logs: List<LogEntry>,
    today: String,
    viewModel: GoalTrackerViewModel
) {
    val goalColor = GoalCalculations.parseHexColor(goal.col)
    var isExpanded by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    var showColorPalette by remember { mutableStateOf(false) }

    // Double-tap armed confirmation states
    var resetArmed by remember { mutableStateOf(false) }
    var deleteArmed by remember { mutableStateOf(false) }

    val goalLogs = remember(logs, goal.id) { logs.filter { it.g == goal.id } }
    val totalMinutes = remember(goalLogs) { goalLogs.sumOf { it.m } }
    val totalUnits = remember(goalLogs) { goalLogs.sumOf { it.u } }

    var editHoursDaily by remember(goal.th) { mutableStateOf(if (goal.th > 0) goal.th.toString() else "") }
    var editHoursTotal by remember(goal.totalHours) { mutableStateOf(if (goal.totalHours > 0) goal.totalHours.toString() else "") }
    var editUnitsName by remember(goal.un) { mutableStateOf(goal.un) }
    var editUnitsDaily by remember(goal.tu) { mutableStateOf(if (goal.tu > 0) goal.tu.toString() else "") }
    var editUnitsTotal by remember(goal.totalCount) { mutableStateOf(if (goal.totalCount > 0) goal.totalCount.toString() else "") }

    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }
    var showSlotStartPicker by remember { mutableStateOf(false) }
    var showSlotEndPicker by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .border(1.dp, goalColor.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        Column {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = "${goal.name}${if (goal.dn != null) " ✓" else ""}",
                        color = goalColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${DateUtils.formatHoursMinutes(totalMinutes)} · ${DateUtils.formatNumber(totalUnits)} ${goal.un}",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                // 3 dots menu
                Box {
                    IconButton(
                        onClick = { menuExpanded = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("•••", color = TextMuted, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = {
                            menuExpanded = false
                            showColorPalette = false
                            resetArmed = false
                            deleteArmed = false
                        },
                        modifier = Modifier.background(DarkCard)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Change colour", color = TextPrimary) },
                            onClick = { showColorPalette = !showColorPalette }
                        )

                        if (showColorPalette) {
                            DropdownMenuItem(
                                text = {
                                    ColorPalettePicker(
                                        selectedColor = goal.col,
                                        onColorSelected = { col ->
                                            viewModel.setGoalColor(goal.id, col)
                                            menuExpanded = false
                                            showColorPalette = false
                                        }
                                    )
                                },
                                onClick = {}
                            )
                        }

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (resetArmed) "Tap again to confirm" else "Reset this goal's data",
                                    color = if (resetArmed) DangerRed else TextPrimary
                                )
                            },
                            onClick = {
                                if (resetArmed) {
                                    viewModel.resetGoalData(goal.id)
                                    menuExpanded = false
                                    resetArmed = false
                                } else {
                                    resetArmed = true
                                }
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (deleteArmed) "Tap again to confirm" else "Delete goal",
                                    color = DangerRed
                                )
                            },
                            onClick = {
                                if (deleteArmed) {
                                    viewModel.deleteGoal(goal.id)
                                    menuExpanded = false
                                    deleteArmed = false
                                } else {
                                    deleteArmed = true
                                }
                            }
                        )
                    }
                }
            }

            // Editable details section
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    // Hours daily & total
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = editHoursDaily,
                            onValueChange = {
                                editHoursDaily = it
                                val num = it.toDoubleOrNull() ?: 0.0
                                viewModel.updateGoal(goal.copy(th = num))
                            },
                            label = { Text("Hours per day", color = TextMuted, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = goalColor,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = editHoursTotal,
                            onValueChange = {
                                editHoursTotal = it
                                val num = it.toDoubleOrNull() ?: 0.0
                                viewModel.updateGoal(goal.copy(totalHours = num))
                            },
                            label = { Text("Total hours", color = TextMuted, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = goalColor,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // What you count & Count daily/total
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = editUnitsName,
                            onValueChange = {
                                editUnitsName = it
                                viewModel.updateGoal(goal.copy(un = it))
                            },
                            label = { Text("What you count", color = TextMuted, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = goalColor,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = editUnitsDaily,
                            onValueChange = {
                                editUnitsDaily = it
                                val num = it.toDoubleOrNull() ?: 0.0
                                viewModel.updateGoal(goal.copy(tu = num))
                            },
                            label = { Text("Count per day", color = TextMuted, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = goalColor,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = editUnitsTotal,
                            onValueChange = {
                                editUnitsTotal = it
                                val num = it.toDoubleOrNull() ?: 0.0
                                viewModel.updateGoal(goal.copy(totalCount = num))
                            },
                            label = { Text("Total count", color = TextMuted, fontSize = 10.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface2,
                                unfocusedContainerColor = DarkSurface2,
                                focusedBorderColor = goalColor,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Start and Deadline
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurface2)
                                .clickable { showStartPicker = true }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Start", color = TextMuted, fontSize = 10.sp)
                                Text(DateUtils.formatDM(goal.s), color = TextPrimary, fontSize = 13.sp)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurface2)
                                .clickable { showEndPicker = true }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Deadline", color = TextMuted, fontSize = 10.sp)
                                Text(DateUtils.formatDM(goal.e), color = TextPrimary, fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Daily slot times
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurface2)
                                .clickable { showSlotStartPicker = true }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("Daily slot from", color = TextMuted, fontSize = 10.sp)
                                Text(goal.ws.ifEmpty { "--:--" }, color = TextPrimary, fontSize = 13.sp)
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurface2)
                                .clickable { showSlotEndPicker = true }
                                .padding(10.dp)
                        ) {
                            Column {
                                Text("until", color = TextMuted, fontSize = 10.sp)
                                Text(goal.we.ifEmpty { "--:--" }, color = TextPrimary, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Overall Progress bars
            val totH = GoalCalculations.totH(goal)
            val doneH = DateUtils.hoursFromMinutes(totalMinutes)
            ProgressBarRow("Hours overall", doneH, DateUtils.round1(totH), goalColor)

            Spacer(modifier = Modifier.height(6.dp))

            val totU = GoalCalculations.totU(goal)
            ProgressBarRow("${goal.un} overall", DateUtils.round1(totalUnits), DateUtils.round1(totU), goalColor)

            // Time left indicator
            Spacer(modifier = Modifier.height(6.dp))
            val timeLeftText = remember(goal, today) {
                when {
                    goal.dn != null -> {
                        "Completed ${DateUtils.formatDM(goal.dn)}${if (!goal.dt.isNullOrEmpty()) " at ${goal.dt}" else ""}${if (goal.dn > goal.e) " (late)" else ""}"
                    }
                    goal.s > today -> "Starts ${DateUtils.formatDM(goal.s)}"
                    else -> {
                        val d = DateUtils.daysDiff(today, goal.e)
                        when {
                            d < 0 -> "Deadline passed (${DateUtils.formatDM(goal.e)}). Keep logging if you're still at it, then mark it completed."
                            d == 0 -> "Last day: deadline is today"
                            else -> "$d day${if (d > 1) "s" else ""} left"
                        }
                    }
                }
            }

            Text(
                text = timeLeftText,
                color = if (goal.dn != null) SuccessGreen else if (DateUtils.daysDiff(today, goal.e) < 0) DangerRed else TextMuted,
                fontSize = 11.sp
            )

            if (goal.ws.isNotEmpty() && goal.we.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Daily slot: ${goal.ws}–${goal.we}", color = TextMuted, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mark completed / Reopen goal button
            if (goal.dn != null) {
                Button(
                    onClick = { viewModel.setGoalCompleted(goal.id, false) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurface2)
                ) {
                    Text("Reopen goal", color = TextPrimary)
                }
            } else {
                Button(
                    onClick = { viewModel.setGoalCompleted(goal.id, true) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = goalColor,
                        contentColor = GoalCalculations.onColor(goal.col)
                    )
                ) {
                    Text("✓ Mark completed", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showStartPicker) {
        CustomDatePickerModal(
            initialDate = goal.s,
            onDismissRequest = { showStartPicker = false },
            onDateSelected = { viewModel.updateGoal(goal.copy(s = it)) }
        )
    }

    if (showEndPicker) {
        CustomDatePickerModal(
            initialDate = goal.e,
            onDismissRequest = { showEndPicker = false },
            onDateSelected = { viewModel.updateGoal(goal.copy(e = it)) }
        )
    }

    if (showSlotStartPicker) {
        CustomTimePickerModal(
            initialTime = goal.ws,
            onDismissRequest = { showSlotStartPicker = false },
            onTimeSelected = { viewModel.updateGoal(goal.copy(ws = it)) }
        )
    }

    if (showSlotEndPicker) {
        CustomTimePickerModal(
            initialTime = goal.we,
            onDismissRequest = { showSlotEndPicker = false },
            onTimeSelected = { viewModel.updateGoal(goal.copy(we = it)) }
        )
    }
}
