package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

data class HeatmapCell(
    val dateStr: String,
    val dayOfMonth: Int,
    val completion: Double?, // null if future/no data, or 0.0 to 1.0+
    val isToday: Boolean
)

@Composable
fun CalendarHeatmap(
    weeks: List<List<HeatmapCell>>, // weeks (Mon to Sun)
    monthHeaders: List<String>,
    accentColor: Color = DefaultAccent,
    modifier: Modifier = Modifier
) {
    val weekDays = listOf("M", "T", "W", "T", "F", "S", "S")
    val scrollState = rememberScrollState()

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
        ) {
            Column {
                // Month labels header
                Row(
                    modifier = Modifier.padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    monthHeaders.forEach { monthLabel ->
                        Text(
                            text = monthLabel,
                            color = TextMuted,
                            fontSize = 10.sp,
                            modifier = Modifier.width(18.dp)
                        )
                    }
                }

                // Grid: 7 rows x N cols
                for (dayOfWeek in 0..6) {
                    Row(
                        modifier = Modifier.padding(vertical = 1.5.dp),
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        weeks.forEach { week ->
                            val cell = week.getOrNull(dayOfWeek)
                            if (cell != null) {
                                val comp = cell.completion
                                val cellBg = if (comp != null && comp > 0) {
                                    val alpha = (0.28f + 0.72f * comp.toFloat().coerceIn(0f, 1f))
                                    accentColor.copy(alpha = alpha)
                                } else {
                                    DarkSurface2
                                }

                                val textColor = if (comp != null && comp > 0.55) {
                                    Color(0xFF06100B)
                                } else {
                                    TextMuted
                                }

                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(cellBg)
                                        .then(
                                            if (cell.isToday) {
                                                Modifier.border(1.5.dp, TextPrimary, RoundedCornerShape(4.dp))
                                            } else {
                                                Modifier
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cell.dayOfMonth.toString(),
                                        color = textColor,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // Right side weekday labels: Mon..Sun
            Column(
                modifier = Modifier
                    .padding(start = 6.dp, top = 16.dp)
            ) {
                weekDays.forEach { wd ->
                    Box(
                        modifier = Modifier.height(21.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = wd,
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}
