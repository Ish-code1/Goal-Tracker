package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.GoalTrackerViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesScreen(
    viewModel: GoalTrackerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val noteContent by viewModel.noteText.collectAsState()
    val noteTitle by viewModel.noteTitle.collectAsState()

    var showClearConfirmDialog by remember { mutableStateOf(false) }

    // Word & character counts
    val wordCount = remember(noteContent) {
        val trimmed = noteContent.trim()
        if (trimmed.isEmpty()) 0 else trimmed.split("\\s+".toRegex()).size
    }
    val charCount = remember(noteContent) { noteContent.length }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("notes_screen")
    ) {
        // TOP SLEEK HEADER CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .border(1.dp, DefaultAccent.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SCRATCHPAD NOTE",
                            color = DefaultAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "One Page Scratchpad",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Status pill: Saved & Count
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(DarkSurface2)
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Saved ✓",
                                color = DefaultAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(99.dp))
                                .background(DarkSurface2)
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$wordCount w · $charCount c",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // QUICK TOOLBAR (Time, Date, Checkbox, Bullet, Copy, Clear)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // + Time stamp
                    QuickInsertChip(
                        label = "+ Time",
                        onClick = {
                            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                            val insertion = if (noteContent.endsWith("\n") || noteContent.isEmpty()) "[$time] " else "\n[$time] "
                            viewModel.updateNoteContent(noteContent + insertion)
                        }
                    )

                    // + Date stamp
                    QuickInsertChip(
                        label = "+ Date",
                        onClick = {
                            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                            val insertion = if (noteContent.endsWith("\n") || noteContent.isEmpty()) "[$date] " else "\n[$date] "
                            viewModel.updateNoteContent(noteContent + insertion)
                        }
                    )

                    // + Checkbox
                    QuickInsertChip(
                        label = "+ [ ]",
                        onClick = {
                            val insertion = if (noteContent.endsWith("\n") || noteContent.isEmpty()) "- [ ] " else "\n- [ ] "
                            viewModel.updateNoteContent(noteContent + insertion)
                        }
                    )

                    // + Bullet
                    QuickInsertChip(
                        label = "+ •",
                        onClick = {
                            val insertion = if (noteContent.endsWith("\n") || noteContent.isEmpty()) "• " else "\n• "
                            viewModel.updateNoteContent(noteContent + insertion)
                        }
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    // Copy button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurface2)
                            .clickable {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Goal Tracker Note", noteContent)
                                clipboard.setPrimaryClip(clip)
                                viewModel.showToast("Note copied to clipboard")
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "Copy",
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Clear button
                    if (noteContent.isNotEmpty() || noteTitle.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkSurface2)
                                .clickable { showClearConfirmDialog = true }
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "Clear",
                                color = DangerRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // NOTE TITLE FIELD
        OutlinedTextField(
            value = noteTitle,
            onValueChange = { viewModel.updateNoteTitle(it) },
            placeholder = { Text("Note Title (optional)", color = TextMuted, fontSize = 15.sp) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("note_title_input"),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkCard,
                unfocusedContainerColor = DarkCard,
                focusedBorderColor = DefaultAccent.copy(alpha = 0.5f),
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // ONE PAGE NOTE EDITOR BODY
        OutlinedTextField(
            value = noteContent,
            onValueChange = { viewModel.updateNoteContent(it) },
            placeholder = {
                Text(
                    text = "Jot down your daily reflections, thoughts, quick scratchpad ideas, meeting notes, or checklists here… Auto-saved instantly.",
                    color = TextMuted.copy(alpha = 0.8f),
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp)
                .testTag("note_content_input"),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkCard,
                unfocusedContainerColor = DarkCard,
                focusedBorderColor = DefaultAccent.copy(alpha = 0.45f),
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            ),
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 14.5.sp,
                lineHeight = 22.sp,
                fontFamily = FontFamily.Default
            )
        )
    }

    // Confirmation dialog before clearing
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Clear Note?", color = TextPrimary) },
            text = { Text("Are you sure you want to erase everything on this page?", color = TextMuted) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearNote()
                        showClearConfirmDialog = false
                    }
                ) {
                    Text("Clear", color = DangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Cancel", color = TextMuted)
                }
            },
            containerColor = DarkCard
        )
    }
}

@Composable
private fun QuickInsertChip(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurface2)
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            text = label,
            color = TextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
