package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider

@Composable
fun MyApplicationTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val colors = when (themeMode) {
        AppThemeMode.DARK -> DarkThemeColors
        AppThemeMode.LIGHT -> LightThemeColors
        AppThemeMode.MIDNIGHT -> MidnightThemeColors
        AppThemeMode.FOREST -> ForestThemeColors
        AppThemeMode.PINK -> PinkThemeColors
        AppThemeMode.PURPLE -> PurpleThemeColors
    }

    updateCurrentAppColors(colors)

    val m3ColorScheme = if (colors.isDark) {
        darkColorScheme(
            primary = colors.accent,
            onPrimary = colors.bg,
            primaryContainer = colors.surface2,
            onPrimaryContainer = colors.textPrimary,
            background = colors.bg,
            onBackground = colors.textPrimary,
            surface = colors.card,
            onSurface = colors.textPrimary,
            surfaceVariant = colors.surface2,
            onSurfaceVariant = colors.textMuted,
            outline = colors.border,
            error = colors.danger,
            onError = colors.textPrimary
        )
    } else {
        lightColorScheme(
            primary = colors.accent,
            onPrimary = colors.card,
            primaryContainer = colors.surface2,
            onPrimaryContainer = colors.textPrimary,
            background = colors.bg,
            onBackground = colors.textPrimary,
            surface = colors.card,
            onSurface = colors.textPrimary,
            surfaceVariant = colors.surface2,
            onSurfaceVariant = colors.textMuted,
            outline = colors.border,
            error = colors.danger,
            onError = colors.card
        )
    }

    CompositionLocalProvider(LocalAppColors provides colors) {
        MaterialTheme(
            colorScheme = m3ColorScheme,
            typography = Typography,
            content = content
        )
    }
}
