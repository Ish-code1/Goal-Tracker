package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Goal
import com.example.data.model.LogEntry
import com.example.ui.components.BucketItem
import com.example.ui.components.CalendarHeatmap
import com.example.ui.components.DonutChart
import com.example.ui.components.ForecastChart
import com.example.ui.components.ForecastChartData
import com.example.ui.components.FreqColumn
import com.example.ui.components.HeatmapCell
import com.example.ui.components.HistoryBarChart
import com.example.ui.components.ScoreLineChart
import com.example.ui.components.WeekdayFrequencyMatrix
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface2
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DefaultAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.GoalTrackerViewModel
import com.example.util.DateUtils
import com.example.util.GoalCalculations
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

@Composable
fun StatsScreen(
    viewModel: GoalTrackerViewModel,
    goals: List<Goal>,
    logs: List<LogEntry>,
    mode: String, // "day", "week", "month", "year", "all"
    anchor: String,
    metric: String, // "m" or "u"
    scope: String, // "all" or goal ID
    historyGrouping: String, // "d", "w", "m"
    scoreGrouping: String, // "d", "w", "m"
    modifier: Modifier = Modifier
) {
    val today = remember { DateUtils.todayDs() }

    // Active goals in scope
    val scopedGoals = remember(goals, logs, scope) {
        val list = if (scope == "all") goals else goals.filter { it.id == scope }
        GoalCalculations.adjustGoals(list, logs)
    }
    val scopedIds = remember(scopedGoals) { scopedGoals.map { it.id }.toSet() }
    val scopedLogs = remember(logs, scopedIds) { logs.filter { scopedIds.contains(it.g) } }
    val agg = remember(scopedLogs) { GoalCalculations.aggregate(scopedLogs) }

    val isSingleGoal = scopedGoals.size == 1
    val singleGoal = scopedGoals.firstOrNull()
    val accentColor = remember(scopedGoals, isSingleGoal) {
        if (isSingleGoal) GoalCalculations.parseHexColor(singleGoal!!.col) else DefaultAccent
    }

    // Units grouping
    val unitGroups = remember(scopedGoals) {
        scopedGoals.groupBy { it.un.trim().lowercase() }
    }
    val isMixedUnits = unitGroups.size > 1 && metric == "u"
    // Different unit types (e.g. questions + videos) must never be summed into one number
    val hasMultiUnits = unitGroups.size > 1
    val unitsLabel = if (scopedGoals.isNotEmpty()) scopedGoals.first().un else "Count"

    // Period boundaries [a, b]
    val (periodStart, periodEnd) = remember(mode, anchor, logs, goals) {
        when (mode) {
            "day" -> Pair(anchor, anchor)
            "week" -> DateUtils.weekRange(anchor)
            "month" -> DateUtils.monthRange(anchor)
            "year" -> {
                val cal = DateUtils.parseDate(anchor)
                val y = cal.get(Calendar.YEAR)
                Pair("$y-01-01", "$y-12-31")
            }
            "all" -> {
                val earliestLog = logs.map { it.d }.minOrNull() ?: today
                val earliestGoal = goals.map { it.s }.minOrNull() ?: today
                val start = minOf(earliestLog, earliestGoal)
                val latestLog = logs.map { it.d }.maxOrNull() ?: today
                val end = maxOf(latestLog, today)
                Pair(start, end)
            }
            else -> DateUtils.weekRange(anchor)
        }
    }

    val periodLabel = remember(mode, periodStart, periodEnd) {
        when (mode) {
            "day" -> {
                val cal = DateUtils.parseDate(periodStart)
                java.text.SimpleDateFormat("EEE, d MMM yyyy", java.util.Locale.ENGLISH).format(cal.time)
            }
            "week" -> "${DateUtils.formatShort(periodStart)} – ${DateUtils.formatShort(periodEnd)}"
            "month" -> {
                val cal = DateUtils.parseDate(periodStart)
                java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.ENGLISH).format(cal.time)
            }
            "year" -> {
                val cal = DateUtils.parseDate(periodStart)
                cal.get(Calendar.YEAR).toString()
            }
            "all" -> "All Time"
            else -> "${DateUtils.formatShort(periodStart)} – ${DateUtils.formatShort(periodEnd)}"
        }
    }

    // Period logs and stats
    val periodLogs = remember(scopedLogs, periodStart, periodEnd) {
        scopedLogs.filter { it.d in periodStart..periodEnd }
    }
    val totalPeriodMinutes = remember(periodLogs) { periodLogs.sumOf { it.m } }
    val totalPeriodUnits = remember(periodLogs) { periodLogs.sumOf { it.u } }

    // Lifetime / All-Time stats
    val lifetimeMinutes = remember(scopedLogs) { scopedLogs.sumOf { it.m } }
    val lifetimeUnits = remember(scopedLogs) { scopedLogs.sumOf { it.u } }
    val lifetimeSessions = remember(scopedLogs) { scopedLogs.size }
    val lifetimeDaysSet = remember(scopedLogs) { scopedLogs.map { it.d }.toSet() }
    val currentStreak = remember(scopedLogs, today) { GoalCalculations.streak(scopedLogs, today) }
    val longestStreak = remember(scopedLogs) { GoalCalculations.longestStreak(scopedLogs) }
    val totalXp = remember(scopedLogs) { GoalCalculations.xpOf(scopedLogs) }
    val userLevel = remember(totalXp) { GoalCalculations.levelOf(totalXp) }

    // Active days in period
    val activeDaysSet = remember(periodLogs) { periodLogs.map { it.d }.toSet() }
    val daysInPeriod = remember(scopedGoals, periodStart, periodEnd, agg) {
        val list = mutableListOf<String>()
        var d = periodStart
        while (d <= periodEnd) {
            if (scopedGoals.any { GoalCalculations.isGoalActiveOnDay(it, d, agg) }) {
                list.add(d)
            }
            d = DateUtils.addDays(d, 1)
        }
        list
    }
    val activeDaysCount = activeDaysSet.size

    // Completion percentage across period
    fun periodValues(g: Goal, p: String, q: String, k: String): Pair<Double, Double> {
        val xLogs = if (mode == "all") {
            scopedLogs.filter { it.g == g.id }
        } else {
            scopedLogs.filter { it.g == g.id && it.d in p..q }
        }
        val done = if (k == "m") xLogs.sumOf { it.m } / 60.0 else xLogs.sumOf { it.u }
        // Completion should be against total target number and not units*days
        val target = if (mode == "all") {
            if (k == "m") GoalCalculations.totH(g) else GoalCalculations.totU(g)
        } else {
            GoalCalculations.periodTarget(g, k, p, q)
        }
        return Pair(done, target)
    }

    fun calcPeriodCompletion(p: String, q: String): Triple<Double, Double, Double?> {
        var doneTotal = 0.0
        var doneActual = 0.0
        var targetTotal = 0.0
        var cappedDone = 0.0

        scopedGoals.forEach { g ->
            val (x, y) = periodValues(g, p, q, metric)
            doneActual += x
            if (y > 0) {
                if (isMixedUnits) {
                    doneTotal += x / y
                    targetTotal += 1.0
                    cappedDone += min(x / y, 1.0)
                } else {
                    doneTotal += x
                    targetTotal += y
                    cappedDone += min(x, y)
                }
            }
        }
        val pct = if (targetTotal > 0) cappedDone / targetTotal else null
        return Triple(if (targetTotal > 0) doneTotal else doneActual, targetTotal, pct)
    }

    val (_, _, currentPeriodPct) = remember(scopedGoals, periodStart, periodEnd, metric) {
        calcPeriodCompletion(periodStart, periodEnd)
    }
    val completionStr = if (currentPeriodPct != null) "${(currentPeriodPct * 100).roundToInt()}%" else "–"

    Column(modifier = modifier.fillMaxWidth()) {
        // TOP LIFETIME OVERVIEW CARD
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(DarkCard)
                .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "LIFETIME OVERVIEW",
                            color = accentColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "All-time Progress",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(99.dp))
                            .background(DarkSurface2)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "$currentStreak day streak (best: $longestStreak)",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    StatTile("Total Time", DateUtils.formatHoursMinutes(lifetimeMinutes), Modifier.weight(1f))
                    StatTile(
                        label = if (hasMultiUnits) "Total Count" else "Total $unitsLabel",
                        value = if (hasMultiUnits) {
                            unitGroups.values.joinToString("\n") { uList ->
                                val ids = uList.map { it.id }.toSet()
                                val sum = scopedLogs.filter { it.g in ids }.sumOf { it.u }
                                "${DateUtils.round1(sum)} ${uList.first().un}"
                            }.ifEmpty { "0" }
                        } else {
                            DateUtils.round1(lifetimeUnits).toString()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    StatTile("Days Active", "${lifetimeDaysSet.size} days", Modifier.weight(1f))
                    StatTile("Sessions", "$lifetimeSessions logs", Modifier.weight(1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Controls Row: Scope & Metric Dropdowns
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Scope Dropdown
            var scopeExpanded by remember { mutableStateOf(false) }
            val scopeTitle = if (scope == "all") "All goals" else goals.find { it.id == scope }?.name ?: "All goals"
            Box(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface2)
                        .clickable { scopeExpanded = true }
                        .padding(12.dp)
                ) {
                    Text(text = "$scopeTitle ▾", color = TextPrimary, fontSize = 13.sp, maxLines = 1)
                }
                DropdownMenu(
                    expanded = scopeExpanded,
                    onDismissRequest = { scopeExpanded = false },
                    modifier = Modifier.background(DarkCard)
                ) {
                    DropdownMenuItem(
                        text = { Text("All goals", color = TextPrimary) },
                        onClick = {
                            viewModel.setStatsScope("all")
                            scopeExpanded = false
                        }
                    )
                    goals.forEach { g ->
                        DropdownMenuItem(
                            text = { Text(g.name, color = GoalCalculations.parseHexColor(g.col)) },
                            onClick = {
                                viewModel.setStatsScope(g.id)
                                scopeExpanded = false
                            }
                        )
                    }
                }
            }

            // Metric Dropdown
            var metricExpanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(DarkSurface2)
                        .clickable { metricExpanded = true }
                        .padding(12.dp)
                ) {
                    Text(
                        text = "${if (metric == "m") "Hours" else "Count"} ▾",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
                DropdownMenu(
                    expanded = metricExpanded,
                    onDismissRequest = { metricExpanded = false },
                    modifier = Modifier.background(DarkCard)
                ) {
                    DropdownMenuItem(
                        text = { Text("Hours", color = TextPrimary) },
                        onClick = {
                            viewModel.setStatsMetric("m")
                            metricExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Count", color = TextPrimary) },
                        onClick = {
                            viewModel.setStatsMetric("u")
                            metricExpanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mode Segment: Day | Week | Month | Year | All-time
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                "day" to "Day",
                "week" to "Week",
                "month" to "Month",
                "year" to "Year",
                "all" to "All-time"
            ).forEach { (key, title) ->
                val isSelected = mode == key
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(if (isSelected) DefaultAccent else DarkSurface2)
                        .clickable { viewModel.setStatsMode(key) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = title,
                        color = if (isSelected) Color(0xFF06100B) else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Navigation Header: ‹ [Label] › with quick Jump to Today
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateStats(-1) },
                enabled = mode != "all",
                modifier = Modifier.size(36.dp)
            ) {
                Text(
                    "‹",
                    color = if (mode != "all") TextPrimary else TextMuted.copy(alpha = 0.3f),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = periodLabel,
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                if (anchor != today && mode != "all") {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Jump to Today ↺",
                        color = DefaultAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { viewModel.resetStatsToToday() }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            IconButton(
                onClick = { viewModel.navigateStats(1) },
                enabled = mode != "all",
                modifier = Modifier.size(36.dp)
            ) {
                Text(
                    "›",
                    color = if (mode != "all") TextPrimary else TextMuted.copy(alpha = 0.3f),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 4 Stat Tiles Card for the selected period
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkCard)
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatTile("Period Time", DateUtils.formatHoursMinutes(totalPeriodMinutes), Modifier.weight(1f))
                    StatTile(
                        label = if (hasMultiUnits) "Period Count" else unitsLabel,
                        value = if (hasMultiUnits) {
                            unitGroups.values.joinToString("\n") { uList ->
                                val uLogs = periodLogs.filter { e -> uList.any { it.id == e.g } }
                                "${DateUtils.round1(uLogs.sumOf { it.u })} ${uList.first().un}"
                            }.ifEmpty { "0" }
                        } else {
                            DateUtils.round1(totalPeriodUnits).toString()
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatTile("Active days", "$activeDaysCount/${max(1, daysInPeriod.size)}", Modifier.weight(1f))
                    StatTile("Completion", completionStr, Modifier.weight(1f))
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 1. Target Section Card
        TargetSectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            anchor = anchor,
            today = today,
            metric = metric,
            isMixedUnits = isMixedUnits,
            accentColor = accentColor
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 2. Donut Section Card
        DonutSectionCard(
            scopedGoals = scopedGoals,
            periodLogs = periodLogs,
            metric = metric,
            isSingleGoal = isSingleGoal,
            isMixedUnits = isMixedUnits,
            periodLabel = periodLabel,
            completionPct = currentPeriodPct ?: 0.0,
            completionStr = completionStr,
            accentColor = accentColor
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Score Section Card
        ScoreSectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            grouping = scoreGrouping,
            anchor = anchor,
            onGroupingChange = { viewModel.setScoreGrouping(it) },
            accentColor = accentColor,
            agg = agg
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 4. History Section Card
        HistorySectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            grouping = historyGrouping,
            anchor = anchor,
            metric = metric,
            onGroupingChange = { viewModel.setHistoryGrouping(it) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 5. Calendar Section Card
        CalendarSectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            today = today,
            accentColor = accentColor,
            agg = agg
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 6. Best Streaks Section Card
        BestStreaksSectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            today = today,
            accentColor = accentColor,
            agg = agg
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 7. Frequency Section Card
        FrequencySectionCard(
            scopedGoals = scopedGoals,
            mode = mode,
            anchor = anchor,
            today = today,
            accentColor = accentColor,
            agg = agg
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 8. Forecast Section Card
        ForecastSectionCard(
            scopedGoals = scopedGoals,
            scopedLogs = scopedLogs,
            metric = metric,
            today = today,
            agg = agg
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 9. RECENT SESSIONS IN THIS PERIOD (Detailed logs list)
        SessionsListCard(
            periodLogs = periodLogs,
            goals = goals
        )
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(horizontal = 4.dp)) {
        Text(text = label, color = TextMuted, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

// 1. TARGET SECTION
@Composable
fun TargetSectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    anchor: String,
    today: String,
    metric: String,
    isMixedUnits: Boolean,
    accentColor: Color
) {
    val periods = listOf("Day", "Week", "Month", "Quarter", "Year", "Overall")

    fun getPeriodRange(k: String): Pair<String, String> {
        val cal = DateUtils.parseDate(anchor)
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH)
        return when (k) {
            "Day" -> Pair(anchor, anchor)
            "Week" -> DateUtils.weekRange(anchor)
            "Month" -> DateUtils.monthRange(anchor)
            "Quarter" -> {
                val qStartMonth = (m / 3) * 3
                val qEndMonth = qStartMonth + 2
                val cStart = Calendar.getInstance().apply { set(y, qStartMonth, 1) }
                val cEnd = Calendar.getInstance().apply {
                    set(y, qEndMonth, 1)
                    set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                }
                Pair(DateUtils.formatDate(cStart), DateUtils.formatDate(cEnd))
            }
            "Overall" -> Pair("2000-01-01", "2099-12-31")
            else -> Pair("$y-01-01", "$y-12-31")
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Target", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (metric == "m") "hours" else if (isMixedUnits) "avg % across goals" else "count",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            periods.forEach { periodName ->
                val (p, q) = getPeriodRange(periodName)
                var doneSum = 0.0
                var targetSum = 0.0
                var cappedDoneSum = 0.0

                if (periodName == "Overall") {
                    scopedGoals.forEach { g ->
                        val xLogs = scopedLogs.filter { it.g == g.id }
                        val x = if (metric == "m") xLogs.sumOf { it.m } / 60.0 else xLogs.sumOf { it.u }
                        val tgt = if (metric == "m") GoalCalculations.totH(g) else GoalCalculations.totU(g)
                        doneSum += x
                        if (tgt > 0) {
                            targetSum += tgt
                            cappedDoneSum += min(x, tgt)
                        }
                    }
                } else {
                    scopedGoals.forEach { g ->
                        val xLogs = scopedLogs.filter { it.g == g.id && it.d in p..q }
                        val x = if (metric == "m") xLogs.sumOf { it.m } / 60.0 else xLogs.sumOf { it.u }
                        val tgt = GoalCalculations.periodTarget(g, metric, p, q)
                        doneSum += x
                        if (tgt > 0) {
                            targetSum += tgt
                            cappedDoneSum += min(x, tgt)
                        }
                    }
                }

                val hasTarget = targetSum > 0
                val progressRatio = if (hasTarget) (cappedDoneSum / targetSum).toFloat().coerceIn(0f, 1f) else 0f
                val rawPct = if (hasTarget) ((doneSum / targetSum) * 100).roundToInt() else 0

                // Today marker position
                val q2 = if (q < today) q else today
                var expectedByTodayRatio: Float? = null
                if (periodName != "Overall" && hasTarget && q > today && p <= today) {
                    var expTarget = 0.0
                    scopedGoals.forEach { g ->
                        expTarget += GoalCalculations.periodTarget(g, metric, p, q2)
                    }
                    expectedByTodayRatio = (expTarget / targetSum).toFloat().coerceIn(0f, 1f)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (periodName == "Day" && anchor == today) "Today" else periodName,
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.width(54.dp)
                    )

                    // Target progress bar container
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(28.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(DarkSurface2),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (progressRatio > 0f) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(progressRatio)
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(if (hasTarget) accentColor else DarkBorder)
                            )
                        }

                        // Today thin marker
                        expectedByTodayRatio?.let { markRatio ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(markRatio)
                                    .height(28.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .width(2.dp)
                                        .height(28.dp)
                                        .background(TextPrimary.copy(alpha = 0.8f))
                                )
                            }
                        }

                        // Centered clear progress label
                        if (doneSum > 0 || hasTarget) {
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .padding(horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val labelText = if (isMixedUnits) "$rawPct%" else "${DateUtils.round1(doneSum)}"
                                Text(
                                    text = labelText,
                                    color = if (progressRatio >= 0.5f && hasTarget) Color(0xFF06100B) else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Right side status text
                    Column(
                        modifier = Modifier.width(96.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        if (hasTarget) {
                            Text(
                                text = "$rawPct%",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${DateUtils.round1(doneSum)} / ${DateUtils.round1(targetSum)}",
                                color = TextMuted,
                                fontSize = 10.sp,
                                maxLines = 1
                            )
                        } else {
                            Text("no target", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Each bar is what you did against the full target for that period (respecting start and deadline). The thin white line marks where you should be by today.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

// 2. DONUT SECTION
@Composable
fun DonutSectionCard(
    scopedGoals: List<Goal>,
    periodLogs: List<LogEntry>,
    metric: String,
    isSingleGoal: Boolean,
    isMixedUnits: Boolean,
    periodLabel: String,
    completionPct: Double,
    completionStr: String,
    accentColor: Color
) {
    val totalDone = scopedGoals.sumOf { g ->
        val gLogs = periodLogs.filter { it.g == g.id }
        if (metric == "m") gLogs.sumOf { it.m } / 60.0 else gLogs.sumOf { it.u }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Donut Breakdown", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(periodLabel, color = TextMuted, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            androidx.compose.foundation.layout.BoxWithConstraints(
                modifier = Modifier.fillMaxWidth()
            ) {
                val availableWidth = maxWidth
                val showTwoDonuts = !isSingleGoal && !isMixedUnits
                val donutDiameter = if (showTwoDonuts) {
                    ((availableWidth - 28.dp) / 2).coerceIn(84.dp, 136.dp)
                } else {
                    136.dp.coerceAtMost(availableWidth - 24.dp)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (showTwoDonuts) {
                        val slices = scopedGoals.map { g ->
                            val gLogs = periodLogs.filter { it.g == g.id }
                            val v = if (metric == "m") gLogs.sumOf { it.m } / 60.0 else gLogs.sumOf { it.u }
                            Pair(v, GoalCalculations.parseHexColor(g.col))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            DonutChart(
                                slices = slices,
                                total = totalDone,
                                centerTitle = DateUtils.round1(totalDone).toString(),
                                centerSubtitle = "total",
                                sizeDp = donutDiameter
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("Share by goal", color = TextMuted, fontSize = 11.sp)
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        DonutChart(
                            slices = listOf(Pair(completionPct.coerceIn(0.0, 1.0), accentColor)),
                            total = 1.0,
                            centerTitle = completionStr,
                            centerSubtitle = "of target",
                            sizeDp = donutDiameter
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Target done", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }

            if (!isSingleGoal) {
                Spacer(modifier = Modifier.height(14.dp))
                scopedGoals.forEach { g ->
                    val gLogs = periodLogs.filter { it.g == g.id }
                    val v = if (metric == "m") gLogs.sumOf { it.m } / 60.0 else gLogs.sumOf { it.u }
                    val gCol = GoalCalculations.parseHexColor(g.col)
                    val sharePct = if (totalDone > 0) ((v / totalDone) * 100).roundToInt() else 0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(gCol)
                            )
                            Text(g.name, color = TextPrimary, fontSize = 13.sp)
                        }
                        val textStr = if (metric == "m") "${DateUtils.round1(v)} h" else "${DateUtils.round1(v)} ${g.un}"
                        Text(
                            text = if (isMixedUnits) textStr else "$textStr · $sharePct%",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

// 3. SCORE SECTION
@Composable
fun ScoreSectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    grouping: String, // "d", "w", "m"
    anchor: String,
    onGroupingChange: (String) -> Unit,
    accentColor: Color,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    val earliestStart = scopedGoals.map { it.s }.minOrNull() ?: anchor
    val alpha = 0.5.pow(1.0 / 13.0)
    val smoothedScores = remember(scopedGoals, scopedLogs, earliestStart, anchor) {
        val map = mutableMapOf<String, Double>()
        var s = 0.0
        var d = earliestStart
        while (d <= anchor) {
            val c = GoalCalculations.completionForDay(scopedGoals, d, agg)
            if (c != null) {
                s = s * alpha + c * (1.0 - alpha)
            }
            map[d] = s
            d = DateUtils.addDays(d, 1)
        }
        map
    }

    // 10 buckets
    val buckets = remember(grouping, anchor) {
        generateBuckets(grouping, anchor, 10)
    }
    val points = buckets.map { (p, q, _) ->
        val end = if (q < anchor) q else anchor
        smoothedScores[end] ?: 0.0
    }
    val currentScore = (points.lastOrNull()?.times(100))?.roundToInt() ?: 0

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Score ", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("$currentScore%", color = DefaultAccent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }

                // Grouping selector
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("d" to "Day", "w" to "Week", "m" to "Month").forEach { (k, n) ->
                        Text(
                            text = n,
                            color = if (grouping == k) DefaultAccent else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (grouping == k) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clickable { onGroupingChange(k) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            ScoreLineChart(
                points = points,
                labels = buckets.map { it.third },
                lineColor = accentColor
            )
        }
    }
}

// 4. HISTORY SECTION
@Composable
fun HistorySectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    grouping: String,
    anchor: String,
    metric: String,
    onGroupingChange: (String) -> Unit
) {
    val buckets = remember(grouping, anchor) {
        generateBuckets(grouping, anchor, 10)
    }

    val bucketItems = remember(buckets, scopedGoals, scopedLogs, metric) {
        buckets.map { (p, q, label) ->
            val slices = scopedGoals.map { g ->
                val gLogs = scopedLogs.filter { it.g == g.id && it.d in p..q }
                val v = if (metric == "m") gLogs.sumOf { it.m } / 60.0 else gLogs.sumOf { it.u }
                Pair(v, GoalCalculations.parseHexColor(g.col))
            }
            val total = slices.sumOf { it.first }
            BucketItem(label = label, slices = slices, total = total)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("History", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("d" to "Day", "w" to "Week", "m" to "Month").forEach { (k, n) ->
                        Text(
                            text = n,
                            color = if (grouping == k) DefaultAccent else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = if (grouping == k) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier
                                .clickable { onGroupingChange(k) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            HistoryBarChart(buckets = bucketItems)
        }
    }
}

// 5. CALENDAR SECTION
@Composable
fun CalendarSectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    today: String,
    accentColor: Color,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    val latestDate = remember(scopedLogs, today) {
        scopedLogs.map { it.d }.maxOrNull()?.let { if (it > today) it else today } ?: today
    }

    val numWeeks = 18
    val (latestMon, _) = remember(latestDate) { DateUtils.weekRange(latestDate) }
    val startMon = remember(latestMon) { DateUtils.addDays(latestMon, -7 * (numWeeks - 1)) }

    val weeksData = remember(startMon, numWeeks, scopedGoals, agg, today) {
        val list = mutableListOf<List<HeatmapCell>>()
        for (w in 0 until numWeeks) {
            val weekStart = DateUtils.addDays(startMon, w * 7)
            val daysList = mutableListOf<HeatmapCell>()
            for (dIdx in 0..6) {
                val d = DateUtils.addDays(weekStart, dIdx)
                val cal = DateUtils.parseDate(d)
                val comp = if (d <= today) GoalCalculations.completionForDay(scopedGoals, d, agg) else null
                daysList.add(
                    HeatmapCell(
                        dateStr = d,
                        dayOfMonth = cal.get(Calendar.DAY_OF_MONTH),
                        completion = comp,
                        isToday = d == today
                    )
                )
            }
            list.add(daysList)
        }
        list
    }

    val monthHeaders = remember(startMon, numWeeks) {
        val list = mutableListOf<String>()
        var prevMonth = -1
        for (w in 0 until numWeeks) {
            val d = DateUtils.addDays(startMon, w * 7)
            val cal = DateUtils.parseDate(d)
            val m = cal.get(Calendar.MONTH)
            if (m != prevMonth) {
                list.add(java.text.SimpleDateFormat("MMM", java.util.Locale.ENGLISH).format(cal.time))
                prevMonth = m
            } else {
                list.add("")
            }
        }
        list
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Calendar Heatmap", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("ringed = today", color = TextMuted, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            CalendarHeatmap(
                weeks = weeksData,
                monthHeaders = monthHeaders,
                accentColor = accentColor
            )
        }
    }
}

// 6. BEST STREAKS SECTION
@Composable
fun BestStreaksSectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    today: String,
    accentColor: Color,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    val earliestStart = scopedGoals.map { it.s }.minOrNull() ?: today
    val latestDate = scopedLogs.map { it.d }.maxOrNull()?.let { if (it > today) it else today } ?: today

    data class StreakRange(val s: String, var e: String, var n: Int)

    val streakRanges = remember(scopedGoals, earliestStart, latestDate, agg, today) {
        val dailyFlags = mutableListOf<Pair<String, Boolean>>()
        var curDate = earliestStart
        while (curDate <= latestDate) {
            val hasLogs = scopedGoals.any { g ->
                val stats = agg[g.id]?.get(curDate)
                stats != null && (stats.m > 0 || stats.u > 0)
            }
            val comp = GoalCalculations.completionForDay(scopedGoals, curDate, agg)
            val success = if (comp != null) (comp >= 0.999 || hasLogs) else hasLogs
            if (curDate != today || success) {
                dailyFlags.add(Pair(curDate, success))
            }
            curDate = DateUtils.addDays(curDate, 1)
        }

        val ranges = mutableListOf<StreakRange>()
        var currentRange: StreakRange? = null
        dailyFlags.forEach { (d, success) ->
            if (success) {
                if (currentRange != null) {
                    currentRange!!.e = d
                    currentRange!!.n++
                } else {
                    currentRange = StreakRange(s = d, e = d, n = 1)
                }
            } else if (currentRange != null) {
                ranges.add(currentRange!!)
                currentRange = null
            }
        }
        currentRange?.let { ranges.add(it) }
        ranges
    }

    val topStreaks = remember(streakRanges) {
        streakRanges.sortedByDescending { it.n }.take(3)
    }

    val currentStreakCount = remember(streakRanges, today) {
        streakRanges.lastOrNull()?.let {
            if (DateUtils.daysDiff(it.e, today) <= 1) it.n else 0
        } ?: 0
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Best Streaks", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("current $currentStreakCount days", color = DefaultAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (topStreaks.isEmpty()) {
                Text("No streak records yet. Complete your daily targets to start a streak!", color = TextMuted, fontSize = 13.sp)
            } else {
                val maxN = max(1, topStreaks.first().n)
                topStreaks.forEachIndexed { idx, range ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(DateUtils.formatD(range.s), color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.width(8.dp))

                        val widthWeight = (range.n.toFloat() / maxN).coerceAtLeast(0.12f)
                        Box(
                            modifier = Modifier
                                .weight(widthWeight)
                                .height(26.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(accentColor.copy(alpha = 1f - idx * 0.35f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${range.n} days",
                                color = Color(0xFF06100B),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))
                        Text(DateUtils.formatD(range.e), color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// 7. FREQUENCY SECTION
@Composable
fun FrequencySectionCard(
    scopedGoals: List<Goal>,
    mode: String,
    anchor: String,
    today: String,
    accentColor: Color,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    val allDays = (0..6).toList()

    val (cols, rows, title) = remember(mode, anchor) {
        when (mode) {
            "month" -> {
                val (f, l) = DateUtils.monthRange(anchor)
                val cList = mutableListOf<FreqColumn>()
                var s0 = DateUtils.weekRange(f).first
                while (s0 <= l) {
                    val dates = allDays.map { k ->
                        val d = DateUtils.addDays(s0, k)
                        if (d in f..l) d else null
                    }
                    val valid = dates.filterNotNull()
                    val label = if (valid.isNotEmpty()) {
                        "${DateUtils.parseDate(valid.first()).get(Calendar.DAY_OF_MONTH)}–${DateUtils.parseDate(valid.last()).get(Calendar.DAY_OF_MONTH)}"
                    } else ""
                    cList.add(FreqColumn(label = label, dates = dates))
                    s0 = DateUtils.addDays(s0, 7)
                }
                Triple(cList, allDays, "each column = a week of ${java.text.SimpleDateFormat("MMMM", java.util.Locale.ENGLISH).format(DateUtils.parseDate(f).time)}")
            }
            "week" -> {
                val w0 = DateUtils.weekRange(anchor).first
                val cList = mutableListOf<FreqColumn>()
                for (i in 5 downTo 0) {
                    val s0 = DateUtils.addDays(w0, -7 * i)
                    val dates = allDays.map { k -> DateUtils.addDays(s0, k) }
                    cList.add(FreqColumn(label = DateUtils.formatShort(s0), dates = dates))
                }
                Triple(cList, allDays, "last 6 weeks, column = week starting that date")
            }
            else -> {
                val cal = DateUtils.parseDate(anchor)
                val jsDay = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7
                val cList = mutableListOf<FreqColumn>()
                for (i in 7 downTo 0) {
                    val d = DateUtils.addDays(anchor, -7 * i)
                    val dates = allDays.map { k -> if (k == jsDay) d else null }
                    cList.add(FreqColumn(label = DateUtils.formatShort(d), dates = dates))
                }
                Triple(cList, listOf(jsDay), "the last 8 times this weekday came round")
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Frequency", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(title, color = TextMuted, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            WeekdayFrequencyMatrix(
                columns = cols,
                rowIndices = rows,
                completionLookup = { d -> GoalCalculations.completionForDay(scopedGoals, d, agg) },
                todayDate = today,
                accentColor = accentColor
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Each circle is one day (ringed = today). Bigger = closer to that day's target.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

// 8. FORECAST SECTION
@Composable
fun ForecastSectionCard(
    scopedGoals: List<Goal>,
    scopedLogs: List<LogEntry>,
    metric: String,
    today: String,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Forecast & Trajectory", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(if (metric == "m") "hours" else "count", color = TextMuted, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (scopedGoals.isEmpty()) {
                Text("Add goals to see forecast predictions.", color = TextMuted, fontSize = 13.sp)
            } else {
                scopedGoals.forEach { g ->
                    SingleGoalForecast(
                        goal = g,
                        scopedLogs = scopedLogs,
                        metric = metric,
                        today = today,
                        agg = agg
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Based on your recent daily pace (recent days weighted higher). An estimate, not a guarantee.",
                color = TextMuted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun SingleGoalForecast(
    goal: Goal,
    scopedLogs: List<LogEntry>,
    metric: String,
    today: String,
    agg: Map<String, Map<String, com.example.util.DayStats>>
) {
    val goalColor = GoalCalculations.parseHexColor(goal.col)
    val targetTotal = if (metric == "m") GoalCalculations.totH(goal) else GoalCalculations.totU(goal)
    val unitStr = if (metric == "m") "h" else goal.un

    fun fmt(v: Double) = "${DateUtils.round1(v)} $unitStr"

    // If goal completed
    if (goal.dn != null) {
        val totalLogged = if (metric == "m") {
            scopedLogs.filter { it.g == goal.id }.sumOf { it.m } / 60.0
        } else {
            scopedLogs.filter { it.g == goal.id }.sumOf { it.u }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 1.dp, color = goalColor.copy(alpha = 0.35f), shape = RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(goal.name, color = goalColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Completed ✓", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Marked done ${DateUtils.formatD(goal.dn)}${if (!goal.dt.isNullOrEmpty()) " at ${goal.dt}" else ""}. You logged ${fmt(totalLogged)}${if (targetTotal > 0) " of ${fmt(targetTotal)}" else ""}.",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
        return
    }

    val daysFromStart = DateUtils.daysDiff(goal.s, today) + 1
    if (daysFromStart < 1) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 1.dp, color = goalColor.copy(alpha = 0.35f), shape = RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column {
                Text(goal.name, color = goalColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Starts ${DateUtils.formatD(goal.s)}", color = TextMuted, fontSize = 12.sp)
            }
        }
        return
    }

    val n = max(1, min(daysFromStart, DateUtils.daysDiff(goal.s, goal.e) + 1))
    val totSpanDays = max(2, DateUtils.daysDiff(goal.s, goal.e) + 1)
    val daysLeft = max(0, DateUtils.daysDiff(today, goal.e))
    val isPast = goal.e < today

    val dailyVals = mutableListOf<Double>()
    for (i in 0 until n) {
        val dStr = DateUtils.addDays(goal.s, i)
        val stats = agg[goal.id]?.get(dStr)
        val v = if (metric == "m") (stats?.m ?: 0) / 60.0 else (stats?.u ?: 0.0)
        dailyVals.add(v)
    }

    val doneSoFar = dailyVals.sum()

    // Exponentially weighted pace estimation
    // Include all elapsed days (up to n) so even Day 1 logging projects forward immediately
    var weightSum = 0.0
    var weightSqSum = 0.0
    var weightedValSum = 0.0
    val mCount = n
    for (i in 0 until mCount) {
        val w = 0.5.pow((mCount - 1 - i).toDouble() / 14.0)
        weightSum += w
        weightSqSum += w * w
        weightedValSum += w * dailyVals[i]
    }
    val paceRate = if (weightSum > 0) weightedValSum / weightSum else 0.0
    var variance = 0.0
    for (i in 0 until mCount) {
        val w = 0.5.pow((mCount - 1 - i).toDouble() / 14.0)
        variance += w * (dailyVals[i] - paceRate).pow(2.0)
    }
    val sd0 = if (weightSum > 0) sqrt(variance / weightSum) else 0.0
    val sd = max(sd0, 0.25 * paceRate)
    val effectiveN = (weightSum * weightSum) / max(0.0001, weightSqSum)

    val remainingTarget = targetTotal - doneSoFar
    val needRate = if (daysLeft > 0) remainingTarget / daysLeft else remainingTarget
    val remToday = if (isPast) 0.0 else max(0.0, paceRate - dailyVals[n - 1])
    val expectedFuture = if (isPast) 0.0 else remToday + paceRate * daysLeft

    val sigma = sqrt(sd * sd * (daysLeft + 1) + (daysLeft * sd / sqrt(max(1.0, effectiveN))).pow(2.0))
    val onTimeProb = when {
        remainingTarget <= 0 -> 1.0
        isPast -> 0.0
        sigma > 0 -> 1.0 - GoalCalculations.phi((remainingTarget - expectedFuture) / sigma)
        else -> if (expectedFuture >= remainingTarget) 1.0 else 0.0
    }

    var projectedFinishDate: String? = null
    if (remainingTarget > 0 && paceRate > 0) {
        val kDays = if (remainingTarget <= remToday) 0 else ceil((remainingTarget - remToday) / paceRate).toInt()
        if (kDays <= 3650) {
            projectedFinishDate = DateUtils.addDays(today, kDays)
        }
    }

    val diffDays = projectedFinishDate?.let { DateUtils.daysDiff(goal.e, it) }
    val threshold = max(1, (0.03 * totSpanDays).roundToInt())
    val vt = max(7, (0.15 * totSpanDays).roundToInt())

    val (statusTitle, statusColor) = when {
        remainingTarget <= 0 -> Pair("Target reached ✓", SuccessGreen)
        isPast -> Pair("Deadline passed", DangerRed)
        diffDays == null -> Pair("Off track", DangerRed)
        diffDays > vt -> Pair("Very late", DangerRed)
        diffDays > threshold -> Pair("Late", WarningOrange)
        diffDays >= -threshold -> Pair("On track", SuccessGreen)
        diffDays >= -vt -> Pair("Early", SuccessGreen)
        else -> Pair("Very early", SuccessGreen)
    }

    val probLabel = when {
        onTimeProb >= 0.85 -> "very likely"
        onTimeProb >= 0.65 -> "likely"
        onTimeProb >= 0.35 -> "about 50/50"
        onTimeProb >= 0.15 -> "unlikely"
        else -> "very unlikely"
    }
    val probStr = when {
        onTimeProb >= 0.99 -> ">99%"
        onTimeProb < 0.01 -> "<1%"
        else -> "${(onTimeProb * 100).roundToInt()}%"
    }

    val s1Text = when {
        remainingTarget <= 0 -> "You've already hit the full target (${fmt(doneSoFar)} of ${fmt(targetTotal)})."
        isPast -> "Deadline was ${DateUtils.formatD(goal.e)}. You ended at ${fmt(doneSoFar)} of ${fmt(targetTotal)}."
        projectedFinishDate != null -> {
            val ad = abs(diffDays ?: 0)
            val rel = if (diffDays == 0) "right on time" else "$ad day${if (ad > 1) "s" else ""} ${if ((diffDays ?: 0) < 0) "early" else "late"}"
            "At this pace you'll finish on ${DateUtils.formatD(projectedFinishDate)}: $rel."
        }
        else -> "At this pace you won't reach the target."
    }

    val s2Text = if (remainingTarget > 0 && !isPast) {
        if (diffDays == null || diffDays > threshold) {
            if (daysLeft > 0) {
                val more = max(0.0, needRate - paceRate)
                "To catch up and finish by ${DateUtils.formatD(goal.e)}: do ${fmt(needRate)}/day (+${fmt(more)} more)."
            } else {
                "Deadline is today: you need ${fmt(remainingTarget)} more today."
            }
        } else if (diffDays < -threshold) {
            "You can ease off: even ${fmt(needRate)}/day still meets the deadline."
        } else {
            "Keep up about ${fmt(needRate)}/day to finish on time."
        }
    } else ""

    // Chart preparation
    val lastIdx = n - 1
    val isLate = projectedFinishDate != null && (diffDays ?: 0) > 0
    val xm = if (isLate) min(ceil(totSpanDays * 1.6).toInt(), DateUtils.daysDiff(goal.s, projectedFinishDate!!) + 3) else totSpanDays
    val yMax = max(targetTotal, doneSoFar) * 1.1

    var cum = 0.0
    val actualPts = dailyVals.mapIndexed { idx, v ->
        cum += v
        Pair(idx, cum)
    }

    val kf = projectedFinishDate?.let { DateUtils.daysDiff(today, it) }
    val hit = kf != null && lastIdx + kf <= xm - 1
    val kE = if (hit) kf!! else xm - 1 - lastIdx
    val ve = if (hit) targetTotal else doneSoFar + remToday + paceRate * kE

    val projPts = if (remainingTarget > 0) {
        listOf(Pair(lastIdx, doneSoFar), Pair(lastIdx + kE, ve))
    } else emptyList()

    val finishPt = if (hit) Pair(lastIdx + kf!!, targetTotal) else null

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = goalColor.copy(alpha = 0.35f), shape = RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(goal.name, color = goalColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(statusTitle, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(s1Text, color = TextPrimary, fontSize = 13.sp)
            if (s2Text.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(s2Text, color = TextMuted, fontSize = 12.sp)
            }

            if (!isPast) {
                Spacer(modifier = Modifier.height(10.dp))
                ForecastChart(
                    data = ForecastChartData(
                        yMax = yMax,
                        target = targetTotal,
                        totalDays = xm,
                        deadlineDayIndex = totSpanDays - 1,
                        actualPoints = actualPts,
                        projectionPoints = projPts,
                        finishPoint = finishPt,
                        finishDateLabel = projectedFinishDate?.let { DateUtils.formatShort(it) } ?: "",
                        startDateLabel = DateUtils.formatShort(goal.s),
                        endDateLabel = DateUtils.formatShort(DateUtils.addDays(goal.s, xm - 1))
                    ),
                    lineColor = goalColor
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Forecast stats grid (2x2 for clean alignment and readable labels)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurface2)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Your pace", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${fmt(paceRate)}/day", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Needed pace", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(if (remainingTarget <= 0) "–" else "${fmt(max(0.0, needRate))}/day", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(DarkBorder)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Projected finish", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(projectedFinishDate?.let { DateUtils.formatD(it) } ?: "–", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("On-time chance", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(if (remainingTarget <= 0) "Done" else if (isPast) "–" else probStr, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (remainingTarget > 0 && !isPast) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "On-time chance: how likely to reach ${fmt(targetTotal)} by ${DateUtils.formatD(goal.e)} ($probLabel).",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }
    }
}

// 9. RECENT SESSIONS IN PERIOD
@Composable
fun SessionsListCard(
    periodLogs: List<LogEntry>,
    goals: List<Goal>
) {
    val sortedLogs = remember(periodLogs) { periodLogs.sortedByDescending { it.d + (it.t.ifEmpty { "00:00" }) } }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(DarkCard)
            .padding(18.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sessions Logged",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${sortedLogs.size} logs",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (sortedLogs.isEmpty()) {
                Text(
                    text = "No sessions logged in this period. Use the Today tab to log an activity.",
                    color = TextMuted,
                    fontSize = 13.sp
                )
            } else {
                sortedLogs.take(15).forEach { log ->
                    val goal = goals.find { it.id == log.g }
                    val goalCol = goal?.let { GoalCalculations.parseHexColor(it.col) } ?: DefaultAccent

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(goalCol)
                        )
                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = goal?.name ?: "Activity",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = DateUtils.formatDM(log.d),
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            if (log.n.isNotEmpty()) {
                                Text(
                                    text = log.n,
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(horizontalAlignment = Alignment.End) {
                            if (log.m > 0) {
                                Text(
                                    text = DateUtils.formatHoursMinutes(log.m),
                                    color = DefaultAccent,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (log.u > 0) {
                                Text(
                                    text = "${DateUtils.round1(log.u)} ${goal?.un ?: ""}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun generateBuckets(grouping: String, anchor: String, n: Int): List<Triple<String, String, String>> {
    val list = mutableListOf<Triple<String, String, String>>()
    when (grouping) {
        "d" -> {
            for (i in n - 1 downTo 0) {
                val d = DateUtils.addDays(anchor, -i)
                val cal = DateUtils.parseDate(d)
                val isFirst = (i == n - 1)
                val isFirstOfMonth = (cal.get(Calendar.DAY_OF_MONTH) == 1)
                val lbl = if (isFirst || isFirstOfMonth) {
                    "${cal.get(Calendar.DAY_OF_MONTH)} ${java.text.SimpleDateFormat("MMM", java.util.Locale.ENGLISH).format(cal.time)}"
                } else {
                    cal.get(Calendar.DAY_OF_MONTH).toString()
                }
                list.add(Triple(d, d, lbl))
            }
        }
        "w" -> {
            val (s, _) = DateUtils.weekRange(anchor)
            for (i in n - 1 downTo 0) {
                val start = DateUtils.addDays(s, -7 * i)
                val end = DateUtils.addDays(start, 6)
                val cal = DateUtils.parseDate(start)
                val isFirst = (i == n - 1)
                val isFirstOfMonth = (cal.get(Calendar.DAY_OF_MONTH) <= 7)
                val lbl = if (isFirst || isFirstOfMonth) {
                    "${cal.get(Calendar.DAY_OF_MONTH)} ${java.text.SimpleDateFormat("MMM", java.util.Locale.ENGLISH).format(cal.time)}"
                } else {
                    cal.get(Calendar.DAY_OF_MONTH).toString()
                }
                list.add(Triple(start, end, lbl))
            }
        }
        else -> {
            for (i in n - 1 downTo 0) {
                val (start, end) = DateUtils.monthRange(anchor, -i)
                val cal = DateUtils.parseDate(start)
                val mName = java.text.SimpleDateFormat("MMM", java.util.Locale.ENGLISH).format(cal.time)
                val lbl = if (i == n - 1 || cal.get(Calendar.MONTH) == 0) {
                    "$mName '${cal.get(Calendar.YEAR).toString().takeLast(2)}"
                } else {
                    mName
                }
                list.add(Triple(start, end, lbl))
            }
        }
    }
    return list
}
